// ═══════════════════════════════════════════════════
// LinkedIn Copilot — "Rede" module (network growth + post monitoring)
// Loaded by background.js via importScripts('network.js').
//
// Action types (all carry action_data.module === 'network'):
//   network_search_people     open a people search page and read the result cards
//   network_search_posts      open a post search page and read the posts
//   network_sync_connections  read recent connections + pending sent invitations
//   network_withdraw_invites  withdraw a few invitations pending for too long
// send_connection_request and post_comment reuse the existing content.js flows.
//
// Page readers are self-contained functions injected with chrome.scripting.executeScript.
// They rely on text and link patterns (not CSS class names) because LinkedIn changes
// class names often. Each reader returns a small `debug` block when it finds nothing,
// so layout changes can be diagnosed from action_queue.result.
// ═══════════════════════════════════════════════════

const NETWORK_ACTION_TYPES = [
  'network_search_people',
  'network_search_posts',
  'network_sync_connections',
  'network_withdraw_invites',
];

function isNetworkAction(action) {
  return !!(action && action.action_data && action.action_data.module === 'network');
}

// ── Page reader: people search results ─────────────────────────────────────
async function lcReadPeopleSearch() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (t) => (t || '').replace(/\s+/g, ' ').trim();
  const lower = (t) => norm(t).toLowerCase();

  // Wait for results (or for an empty/limit state)
  for (let i = 0; i < 20; i++) {
    if (document.querySelectorAll('main a[href*="/in/"]').length > 0) break;
    const body = lower(document.body && document.body.innerText);
    if (body.includes('no results found') || body.includes('nenhum resultado')) break;
    await sleep(500);
  }

  const bodyText = lower(document.body && document.body.innerText);
  const LIMIT_PHRASES = [
    'commercial use limit', 'reached the monthly limit for profile searches',
    'limite de uso comercial', 'atingiu o limite mensal de pesquisas',
  ];
  if (LIMIT_PHRASES.some((p) => bodyText.includes(p))) {
    return { success: true, limit_reached: true, profiles: [], has_next: false };
  }

  // Scroll like a person reading the page so lazy cards render
  for (let i = 0; i < 5; i++) {
    window.scrollBy(0, 500 + Math.random() * 300);
    await sleep(700 + Math.random() * 700);
  }
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(1200);

  const anchors = Array.from(document.querySelectorAll('main a[href*="/in/"]'));
  const containers = [];
  const seen = new Set();
  for (const a of anchors) {
    const m = (a.getAttribute('href') || '').match(/\/in\/([^/?#]+)/);
    if (!m) continue;
    const slug = m[1].toLowerCase();
    if (seen.has(slug)) continue;
    const box = a.closest('li') || a.closest('[data-chameleon-result-urn]') || a.closest('[data-view-name="search-entity-result-universal-template"]');
    if (!box) continue;
    // Skip "people also viewed"/ads blocks outside the main result list
    if (box.querySelectorAll('a[href*="/in/"]').length > 6) continue;
    seen.add(slug);
    containers.push({ slug, href: a.href, box });
  }

  const DEGREE_RE = /(?:^|\s|•)\s*(1st|2nd|3rd\+?|1º|2º|3º\+?)(?:\s|$)/i;
  const profiles = [];
  for (const { slug, href, box } of containers) {
    const raw = (box.innerText || '').split('\n').map(norm).filter(Boolean);
    const lines = raw.filter((l, i) => l !== raw[i - 1]);
    const text = lines.join(' | ');
    const anchor = box.querySelector(`a[href*="/in/${slug}"]`) || box.querySelector('a[href*="/in/"]');
    let name = norm(anchor && (anchor.querySelector('span[aria-hidden="true"]') || anchor).textContent);
    name = name.replace(/view .*profile$/i, '').replace(/ver perfil.*$/i, '').trim();
    if (!name || /linkedin member|membro do linkedin/i.test(name)) continue;

    const degreeMatch = text.match(DEGREE_RE);
    let degree = degreeMatch ? degreeMatch[1].toLowerCase() : null;
    if (degree) degree = degree.replace('º', degree.startsWith('1') ? 'st' : degree.startsWith('2') ? 'nd' : 'rd');

    let mutual = null;
    let mm;
    if ((mm = text.match(/(\d[\d.,]*)\s+other mutual connections?/i))) mutual = parseInt(mm[1].replace(/\D/g, ''), 10) + 2;
    else if ((mm = text.match(/(\d[\d.,]*)\s+outras?\s+conex(?:ão|ões) em comum/i))) mutual = parseInt(mm[1].replace(/\D/g, ''), 10) + 2;
    else if ((mm = text.match(/(\d[\d.,]*)\s+mutual connections?/i))) mutual = parseInt(mm[1].replace(/\D/g, ''), 10);
    else if ((mm = text.match(/(\d[\d.,]*)\s+conex(?:ão|ões) em comum/i))) mutual = parseInt(mm[1].replace(/\D/g, ''), 10);
    else if (/are mutual connections|são conexões em comum/i.test(text)) mutual = 2;
    else if (/is a mutual connection|é uma conexão em comum/i.test(text)) mutual = 1;

    // Headline / location = first informative lines after the name
    const skip = (l) =>
      l === name || (l.startsWith(name) && /profile|perfil|•|\b(1st|2nd|3rd)\b/i.test(l)) ||
      DEGREE_RE.test(` ${l} `) && l.length < 20 || /view .*profile/i.test(l) || /ver perfil/i.test(l) ||
      /^status is/i.test(l) || /mutual connection|conex(ão|ões) em comum/i.test(l) ||
      /^(connect|conectar|follow|seguir|message|mensagem|pending|pendente)$/i.test(l) || /^•/.test(l);
    const info = lines.filter((l) => !skip(l));
    const headline = info[0] || null;
    const loc = info[1] || null;
    const snippet = info.slice(2, 4).join(' | ') || null;
    let currentCompany = null;
    if (headline) {
      const c = headline.match(/\s(?:at|na|no|em|@)\s+(.+)$/i);
      if (c) currentCompany = c[1].split('|')[0].trim();
    }

    const buttons = Array.from(box.querySelectorAll('button, a[role="button"]')).map((b) =>
      lower(`${b.textContent || ''} ${b.getAttribute('aria-label') || ''}`));
    const isPending = buttons.some((b) => /\bpending\b|pendente|withdraw|retirar/.test(b));
    const isConnected = degree === '1st';

    profiles.push({
      profile_url: href.split('?')[0],
      name,
      headline,
      location: loc,
      current_company: currentCompany,
      degree,
      mutual_connections: mutual,
      is_pending: isPending,
      is_connected: isConnected,
      snippet,
    });
  }

  const nextBtn = Array.from(document.querySelectorAll('button')).find((b) => {
    const l = lower(`${b.getAttribute('aria-label') || ''} ${b.textContent || ''}`);
    return (l.includes('next') || l.includes('avançar') || l.includes('próxima') || l.includes('próximo')) && !b.disabled;
  });

  const result = { success: true, profiles, has_next: !!nextBtn, page_url: location.href };
  if (profiles.length === 0) {
    result.debug = {
      anchors: anchors.length,
      containers: containers.length,
      sample: containers[0] ? (containers[0].box.innerText || '').slice(0, 400) : (document.querySelector('main') || document.body).innerText.slice(0, 400),
    };
  }
  return result;
}

// ── Page reader: Sales Navigator lead search ──────────────────────────────
// Reads the lead cards, then turns each Sales Navigator lead into the person's public
// linkedin.com/in/ URL (the rest of the system, invites and acceptance sync, works on those).
// Leads whose public URL cannot be found are left out. If nothing can be used, it returns
// sales_nav_unavailable so the backend falls back to the regular search for 24h.
//
// Sales Navigator paints the lead cards lazily (only the cards scrolled into view, and only while
// the tab is visible). The automation tab usually runs in the background, so the cards are often
// never painted even though the page has loaded the results ("29 results" and the "Add X to
// selection" checkboxes are there, the names and links are not). When the cards are missing or
// incomplete, the reader re-reads the search through the same lead-search call the page itself
// made (visible in the page's resource timing), which does not depend on painting.
async function lcReadSalesNavSearch() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (t) => (t || '').replace(/\s+/g, ' ').trim();
  const lower = (t) => norm(t).toLowerCase();
  const PAGE_SIZE = 25;
  const leadLinks = () => Array.from(document.querySelectorAll('a[href*="/sales/lead/"]'));
  const resultsPanel = () => document.querySelector('#search-results-container');
  const emptyState = () => /no leads matched|no results|nenhum lead|nenhum resultado/.test(lower(document.body && document.body.innerText));
  // The page's own lead-search request (the most recent one), from resource timing.
  const pageSearchCall = () => {
    const urls = performance.getEntriesByType('resource').map((r) => r.name).filter((u) => u.includes('/sales-api/salesApiLeadSearch?'));
    return urls.length ? urls[urls.length - 1] : null;
  };
  const unavailable = (reason, extra) => ({
    success: true, sales_nav_unavailable: true, reason, profiles: [], has_next: false,
    debug: { url: location.href, sample: ((document.querySelector('main') || document.body || {}).innerText || '').slice(0, 400), ...(extra || {}) },
  });
  const csrf = ((document.cookie.match(/JSESSIONID=["']?([^;"']+)/) || [])[1] || '').replace(/"/g, '');
  const apiHeaders = { 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0', accept: 'application/json' };

  // Wait for cards, for the page's search call to have happened, for an empty state, or for a
  // redirect away from the search (no license / contract chooser). Nudge the results panel while
  // waiting: scrolling is what makes the cards paint when the tab is visible.
  for (let i = 0; i < 40; i++) {
    if (leadLinks().length > 0) break;
    if (emptyState()) break;
    if (!location.pathname.startsWith('/sales/search')) break;
    if (i >= 12 && pageSearchCall()) break; // results are loaded; the cards just are not painted
    const panel = resultsPanel();
    if (panel && i % 3 === 2) panel.scrollBy(0, 250);
    await sleep(500);
  }
  if (!location.pathname.startsWith('/sales/search')) {
    return unavailable(/contract/i.test(location.pathname) ? 'contract_chooser' : 'not_on_sales_navigator');
  }

  const bodyText = lower(document.body && document.body.innerText);
  if (/commercial use limit|limite de uso comercial|reached the (monthly|daily) limit/.test(bodyText)) {
    return { success: true, limit_reached: true, profiles: [], has_next: false };
  }

  // Results live in their own scrolling panel: scroll it like a person so all 25 cards render.
  const first = leadLinks()[0];
  let scroller = resultsPanel();
  if (!scroller && first) {
    let el = first.parentElement;
    while (el && el !== document.body) {
      const st = getComputedStyle(el);
      if (/(auto|scroll)/.test(st.overflowY) && el.scrollHeight > el.clientHeight + 50) { scroller = el; break; }
      el = el.parentElement;
    }
  }
  for (let i = 0; i < 8; i++) {
    if (scroller) scroller.scrollBy(0, 450 + Math.random() * 250); else window.scrollBy(0, 450 + Math.random() * 250);
    await sleep(700 + Math.random() * 700);
  }
  await sleep(1000);

  // 1) Lead cards that were painted
  const leads = [];
  const seen = new Set();
  for (const a of leadLinks()) {
    const href = a.getAttribute('href') || '';
    const m = href.match(/\/sales\/lead\/([^,/?#]+),([^,/?#]+),([^/?#]+)/);
    if (!m || seen.has(m[1])) continue;
    const box = a.closest('li') || a.closest('[data-x-search-result]') || a.closest('article');
    if (!box) continue;
    seen.add(m[1]);
    const pick = (sel) => norm((box.querySelector(sel) || {}).textContent);
    const text = norm(box.innerText);
    const name = pick('[data-anonymize="person-name"]') || norm(a.textContent);
    if (!name || /linkedin member|membro do linkedin/i.test(name)) continue;
    const title = pick('[data-anonymize="title"]') || null;
    const company = pick('[data-anonymize="company-name"]') || null;
    const loc = pick('[data-anonymize="location"]') || null;
    const degM = text.match(/\b(1st|2nd|3rd\+?)\b|\b(1º|2º|3º\+?)/i);
    let degree = degM ? (degM[1] || degM[2]).toLowerCase() : null;
    if (degree && degree.includes('º')) degree = degree.startsWith('1') ? '1st' : degree.startsWith('2') ? '2nd' : '3rd';
    leads.push({
      id: m[1], authType: m[2], authToken: decodeURIComponent(m[3]),
      name, title, company, location: loc, degree,
      is_pending: /\bpending\b|pendente/i.test(text),
      recently_posted: /recently posted|posted on linkedin|publicou recentemente|publicou no linkedin/i.test(text),
      changed_jobs: /changed jobs|recently hired|new in role|mudou de emprego|novo cargo/i.test(text),
    });
  }

  // 2) Cards missing or incomplete: re-read the search through the page's own lead-search call.
  //    "N results" in the page tells how many to expect on this page.
  const totalM = bodyText.match(/(\d[\d,.]*)\s+(?:results?|resultados?)\b/);
  const totalOnPage = totalM ? parseInt(totalM[1].replace(/\D/g, ''), 10) : null;
  const params = new URLSearchParams(location.search);
  const pageNo = Math.max(1, parseInt(params.get('page') || '1', 10) || 1);
  const expected = totalOnPage == null ? PAGE_SIZE : Math.max(0, Math.min(PAGE_SIZE, totalOnPage - (pageNo - 1) * PAGE_SIZE));
  let api = null; // { start, count, total, status, error }
  if (leads.length < expected && !emptyState()) {
    let url = pageSearchCall();
    if (!url && params.get('query')) {
      // The Rest.li query goes in as the page shows it after one URL decode (inner text keeps its %20);
      // encoding it again returns 400. Verified against the page's own call on 2026-11-07.
      url = '/sales-api/salesApiLeadSearch?q=searchQuery&query=' + params.get('query') +
        `&start=${(pageNo - 1) * PAGE_SIZE}&count=${PAGE_SIZE}&decorationId=com.linkedin.sales.deco.desktop.searchv2.LeadSearchResult-17`;
    }
    if (url) {
      try {
        const r = await fetch(url, { credentials: 'include', headers: apiHeaders });
        api = { status: r.status, url: url.replace(/trackingParam=[^&]*/, 'trackingParam=…') };
        if (r.status === 401 || r.status === 403) return unavailable('no_license', { status: r.status });
        if (r.ok) {
          const j = await r.json();
          const u = new URL(url, location.origin);
          api.start = parseInt(u.searchParams.get('start') || '0', 10) || 0;
          api.count = 0;
          api.total = j && j.paging && typeof j.paging.total === 'number' ? j.paging.total : null;
          for (const el of (j && Array.isArray(j.elements) ? j.elements : [])) {
            api.count++;
            const um = String(el.entityUrn || '').match(/\(([^,)]+),([^,)]+),([^)]+)\)/);
            if (!um || seen.has(um[1])) continue;
            const name = norm(el.fullName || `${el.firstName || ''} ${el.lastName || ''}`);
            if (!name || /linkedin member|membro do linkedin/i.test(name)) continue;
            seen.add(um[1]);
            const pos = Array.isArray(el.currentPositions) && el.currentPositions[0] ? el.currentPositions[0] : {};
            const deg = Number(el.degree);
            leads.push({
              id: um[1], authType: um[2], authToken: decodeURIComponent(um[3]),
              name,
              title: norm(pos.title) || null,
              company: norm(pos.companyName) || null,
              location: norm(el.geoRegion) || null,
              degree: deg === 1 ? '1st' : deg === 2 ? '2nd' : deg === 3 ? '3rd' : null,
              is_pending: el.pendingInvitation === true,
              recently_posted: false,
              changed_jobs: false,
            });
          }
        }
      } catch (e) {
        api = { ...(api || {}), error: String(e && e.message || e) };
      }
    }
  }

  if (leads.length === 0) {
    if (emptyState() || (api && api.total === 0)) return { success: true, profiles: [], has_next: false, page_url: location.href };
    return unavailable('no_lead_cards', { links: leadLinks().length, results_total: totalOnPage, api });
  }

  // Public profile URL for each lead (the same call Sales Navigator makes when a lead is opened)
  const resolve = async (l) => {
    const path = `/sales-api/salesApiProfiles/(profileId:${l.id},authType:${l.authType},authToken:${encodeURIComponent(l.authToken)})` +
      '?decoration=%28entityUrn%2CflagshipProfileUrl%29';
    const r = await fetch(path, {
      credentials: 'include',
      headers: { 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0', accept: 'application/json' },
    });
    if (!r.ok) throw new Error(`profile ${r.status}`);
    const t = await r.text();
    const mm = t.match(/linkedin\.com\/in\/([^"\\/?#]+)/);
    return mm ? `https://www.linkedin.com/in/${mm[1]}` : null;
  };

  const profiles = [];
  let failures = 0;
  let lastError = null;
  for (const l of leads) {
    if (failures >= 3 && profiles.length === 0) break; // the lookup is not working: stop early
    let url = null;
    try { url = await resolve(l); } catch (e) { lastError = String(e && e.message || e); }
    if (!url) { failures++; } else {
      profiles.push({
        profile_url: url,
        name: l.name,
        headline: l.title && l.company ? `${l.title} at ${l.company}` : (l.title || l.company || null),
        location: l.location,
        current_company: l.company,
        degree: l.degree,
        mutual_connections: null,
        is_pending: l.is_pending,
        is_connected: l.degree === '1st',
        recently_posted: l.recently_posted,
        changed_jobs: l.changed_jobs,
        snippet: [l.title, l.company].filter(Boolean).join(' | ') || null,
      });
    }
    await sleep(350 + Math.random() * 550);
  }
  if (profiles.length === 0) return unavailable('profile_lookup_failed', { leads: leads.length, error: lastError });

  // Next page: from the search call's paging when we have it, otherwise from the Next button.
  let hasNext;
  if (api && typeof api.total === 'number' && typeof api.start === 'number') {
    hasNext = api.start + Math.max(api.count || 0, leads.length) < api.total;
  } else if (totalOnPage != null) {
    hasNext = pageNo * PAGE_SIZE < totalOnPage;
  } else {
    const nextBtn = Array.from(document.querySelectorAll('button')).find((b) => {
      const l = lower(`${b.getAttribute('aria-label') || ''} ${b.textContent || ''}`);
      return /\bnext\b|avançar|próxim/.test(l) && !b.disabled && b.getAttribute('aria-disabled') !== 'true';
    });
    hasNext = !!nextBtn;
  }

  return {
    success: true, reader: 'sales_navigator', profiles, has_next: hasNext, page_url: location.href,
    leads_on_page: leads.length, unresolved: leads.length - profiles.length,
    results_total: api && typeof api.total === 'number' ? api.total : totalOnPage,
    source: api && api.count ? (leadLinks().length ? 'cards+search_call' : 'search_call') : 'cards',
  };
}

// ── Page check: which LinkedIn plan is this account on? ───────────────────
// Runs inside any linkedin.com tab. Returns { tier, signals } or { tier: null } when unsure.
async function lcDetectLinkedInTier() {
  const csrf = ((document.cookie.match(/JSESSIONID=["']?([^;"']+)/) || [])[1] || '').replace(/"/g, '');
  const signals = { licenses_checked: false, sales_nav_license: false, nav_link: false, premium: null };

  try {
    const r = await fetch('/sales-api/salesApiIdentity?q=findLicensesByCurrentMember&includeRecentlyRevokedLicenses=false', {
      credentials: 'include',
      headers: { 'csrf-token': csrf, 'x-restli-protocol-version': '2.0.0', accept: 'application/json' },
    });
    if (r.ok) {
      const j = await r.json().catch(() => null);
      const els = (j && (j.elements || j.data && j.data.elements)) || [];
      signals.licenses_checked = Array.isArray(els);
      signals.sales_nav_license = Array.isArray(els) && els.some((e) => e && e.active !== false && e.revoked !== true);
    } else if (r.status === 403 || r.status === 404) {
      signals.licenses_checked = true; // the API answered: no Sales Navigator seat
    }
  } catch (_) { /* inconclusive */ }

  const nav = document.querySelector('#global-nav, header.global-nav, header');
  if (nav) {
    signals.nav_link = Array.from(nav.querySelectorAll('a[href*="/sales/"]')).some((a) =>
      /sales nav/i.test(`${a.textContent || ''} ${a.getAttribute('aria-label') || ''}`));
  }

  try {
    const r = await fetch('/voyager/api/me', {
      credentials: 'include',
      headers: { 'csrf-token': csrf, accept: 'application/vnd.linkedin.normalized+json+2.1' },
    });
    if (r.ok) {
      const t = await r.text();
      signals.premium = /"premiumSubscriber"\s*:\s*true/.test(t);
    }
  } catch (_) { /* inconclusive */ }

  let tier = null;
  // The license check is the source of truth; the nav link only counts when that check was inconclusive.
  if (signals.sales_nav_license || (signals.nav_link && !signals.licenses_checked)) tier = 'sales_navigator';
  else if (signals.premium === true) tier = 'premium';
  else if (signals.premium === false) tier = 'free';
  return { tier, signals };
}

// ── Page reader: post (content) search results ─────────────────────────────
// Self-contained (it is injected into the page). The 2026 search page has no data-urn and no
// stable class names: a post card is found from its relative-time label ("1d •", "2w • Edited •"),
// the same way the activity page is read in content.js. The old data-urn layout is kept as a
// fallback. No call to LinkedIn's internal services is made here: only what is on the page is read.
async function lcReadPostSearch() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (t) => (t || '').replace(/\s+/g, ' ').trim();
  const AGE_RE = /^(\d+)\s?(min|h|d|w|mo|yr|m|sem|a)(\s*[•·]\s*(edited|editado|modifié|editada))?\s*[•·]?$/i;
  const HEADER_RE = /^(feed post|publicação( do| no)? feed|post)$/i;
  const REPOST_RE = /reposted|republicou|compartilhou (isso|esta|este)|shared this|ha compartido|a republié|a partagé/i;
  const END_RE = /^(like|comment|repost|send|share|gostei|comentar|compartilhar|enviar|reagir|show translation|see translation|ver tradução|mostrar tradução|\d[\d,.]*\s*(reactions?|comments?|reposts?|reações|comentários|compartilhamentos))$/i;
  const ownText = (el) => {
    let t = '';
    for (const n of el.childNodes) if (n.nodeType === 3) t += n.nodeValue;
    return norm(t);
  };
  const isAgeSpan = (s) => {
    if (!AGE_RE.test(ownText(s))) return false;
    for (const c of s.querySelectorAll('span')) if (c.textContent.trim()) return false;
    return true;
  };
  const main = document.querySelector('main') || document.body;
  const ageSpansIn = (root) => Array.from(root.querySelectorAll('span')).filter(isAgeSpan);

  const findCards = () => {
    const cards = [];
    const seen = new Set();
    for (const span of ageSpansIn(main)) {
      let el = span;
      let card = span;
      while (el && el !== main) {
        if (ageSpansIn(el).length > 1) break;
        card = el;
        el = el.parentElement;
      }
      if (card === span || seen.has(card)) continue;
      seen.add(card);
      cards.push({ card, span });
    }
    return cards;
  };
  const findOld = () => {
    const els = Array.from(document.querySelectorAll(
      '[data-urn^="urn:li:activity"], [data-id^="urn:li:activity"], [data-urn^="urn:li:ugcPost"], [data-urn^="urn:li:share"]'
    ));
    return els.filter((el) => !els.some((o) => o !== el && o.contains(el)));
  };

  for (let i = 0; i < 24 && findCards().length === 0 && findOld().length === 0; i++) await sleep(500);
  for (let i = 0; i < 6; i++) {
    window.scrollBy(0, 700 + Math.random() * 400);
    await sleep(900 + Math.random() * 900);
  }

  const posts = [];
  for (const { card, span } of findCards().slice(0, 25)) {
    const lines = card.innerText.replace(/[ \t]+/g, ' ').split(/\n+/).map((l) => l.trim()).filter(Boolean);
    const hIdx = lines.findIndex((l) => HEADER_RE.test(l));
    const ageLabel = ownText(span).replace(/\s*[•·]\s*$/, '');
    const ageIdx = lines.findIndex((l) => l === ageLabel || l.startsWith(`${ageLabel} •`) || l.startsWith(`${ageLabel} ·`));
    const headEnd = ageIdx >= 0 ? ageIdx : Math.max(hIdx, 0) + 3;
    const head = lines.slice(0, headEnd);
    if (REPOST_RE.test(head.join(' '))) continue; // only the author's own posts
    const authorName = (hIdx >= 0 ? (lines[hIdx + 1] || '') : (lines[0] || '')).split(/\s[•·]\s/)[0].trim();
    const degreeM = head.join(' ').match(/[•·]\s*(1st|2nd|3rd\+?|1º|2º|3º\+?)/i);
    // Headline: the line between the name/degree lines and the age label.
    const headline = head.slice(Math.max(hIdx, 0) + 1)
      .filter((l) => l !== authorName && !/^[•·]\s*(1st|2nd|3rd\+?|1º|2º|3º\+?)$/i.test(l) && !/^(follow|following|seguir|seguindo)$/i.test(l))
      .slice(-1)[0] || null;
    let body = lines.slice(ageIdx + 1).filter((l) => !/^(follow|following|seguir|seguindo|\+ ?follow)$/i.test(l));
    const cut = body.findIndex((l) => END_RE.test(l));
    if (cut >= 0) body = body.slice(0, cut);
    const text = body.join('\n').replace(/\s*(…\s*more|…\s*ver mais|\.\.\.\s*more)$/i, '').trim();
    const authorA = card.querySelector('a[href*="/in/"]');
    const reactM = card.innerText.match(/([\d.,]+)\s+(reactions?|reações)/i);
    const commM = card.innerText.match(/([\d.,]+)\s+(comments?|comentários?)/i);
    posts.push({
      urn: null,
      text: text.slice(0, 5000),
      author_name: authorName || null,
      author_headline: headline,
      author_profile_url: authorA ? authorA.href.split('?')[0] : null,
      author_degree: degreeM ? degreeM[1] : null,
      posted_label: ageLabel.slice(0, 40) || null,
      reactions: reactM ? reactM[1] : null,
      comments: commM ? commM[1] : null,
    });
  }

  // Old layout (kept as a fallback)
  if (posts.length === 0) {
    for (const el of findOld().slice(0, 25)) {
      const urn = el.getAttribute('data-urn') || el.getAttribute('data-id') || '';
      if (!urn) continue;
      const textEl = el.querySelector('.update-components-text, .feed-shared-inline-show-more-text, .feed-shared-update-v2__description');
      const actor = el.querySelector('.update-components-actor, .feed-shared-actor') || el;
      const authorA = actor.querySelector('a[href*="/in/"]') || el.querySelector('a[href*="/in/"]');
      const degreeM = norm(actor.innerText).match(/•\s*(1st|2nd|3rd\+?|1º|2º|3º\+?)/i);
      posts.push({
        urn,
        text: norm(textEl && textEl.innerText).slice(0, 5000),
        author_name: norm(authorA && authorA.innerText).split('\n')[0] || null,
        author_headline: norm((actor.querySelector('.update-components-actor__description, .feed-shared-actor__description') || {}).textContent) || null,
        author_profile_url: authorA ? authorA.href.split('?')[0] : null,
        author_degree: degreeM ? degreeM[1] : null,
        posted_label: null, reactions: null, comments: null,
      });
    }
  }

  const result = { success: true, posts, own_profile_url: null };
  if (posts.length === 0) {
    result.debug = { sample: (document.querySelector('main') || document.body).innerText.slice(0, 400) };
  }
  return result;
}

// ── Page reader: list of profile links on the current page (connections / sent invites) ──
async function lcReadProfileLinks(maxScrolls) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let i = 0; i < 20 && document.querySelectorAll('main a[href*="/in/"]').length === 0; i++) await sleep(500);
  for (let i = 0; i < (maxScrolls || 4); i++) {
    window.scrollTo(0, document.body.scrollHeight);
    await sleep(1200 + Math.random() * 800);
    const showMore = Array.from(document.querySelectorAll('main button')).find((b) =>
      /show more results|mostrar mais resultados|load more|carregar mais/i.test(b.textContent || ''));
    if (showMore) { showMore.click(); await sleep(1500); }
  }
  const urls = new Set();
  for (const a of document.querySelectorAll('main a[href*="/in/"]')) {
    const m = (a.getAttribute('href') || '').match(/\/in\/([^/?#]+)/);
    if (m) urls.add(`https://www.linkedin.com/in/${m[1]}`);
  }
  return { success: true, urls: Array.from(urls).slice(0, 300) };
}

// ── Page action: withdraw selected sent invitations ───────────────────────
async function lcWithdrawInvites(profileUrls) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const slugOf = (u) => ((u || '').match(/\/in\/([^/?#]+)/) || [])[1];
  const targets = (profileUrls || []).map((u) => {
    const s = slugOf(u);
    try { return s ? decodeURIComponent(s).toLowerCase() : null; } catch (_) { return s ? s.toLowerCase() : null; }
  }).filter(Boolean);

  for (let i = 0; i < 20 && document.querySelectorAll('main a[href*="/in/"]').length === 0; i++) await sleep(500);
  for (let i = 0; i < 4; i++) { window.scrollTo(0, document.body.scrollHeight); await sleep(1200); }

  const withdrawn = [];
  const notFound = [];
  for (const slug of targets.slice(0, 10)) {
    const link = Array.from(document.querySelectorAll('main a[href*="/in/"]')).find((a) => {
      const s = slugOf(a.getAttribute('href'));
      if (!s) return false;
      let d = s; try { d = decodeURIComponent(s); } catch (_) { /* keep */ }
      return d.toLowerCase() === slug;
    });
    const card = link && (link.closest('li') || link.closest('[data-view-name]') || link.parentElement);
    const btn = card && Array.from(card.querySelectorAll('button')).find((b) =>
      /withdraw|retirar|cancelar convite/i.test(`${b.textContent || ''} ${b.getAttribute('aria-label') || ''}`));
    if (!btn) { notFound.push(`https://www.linkedin.com/in/${slug}`); continue; }
    btn.scrollIntoView({ block: 'center' });
    await sleep(800 + Math.random() * 600);
    btn.click();
    await sleep(1200 + Math.random() * 600);
    const dialog = document.querySelector('div[role="alertdialog"], div[role="dialog"], dialog');
    const confirm = dialog && Array.from(dialog.querySelectorAll('button')).find((b) =>
      /^(withdraw|retirar|confirmar)$/i.test((b.textContent || '').trim()));
    if (confirm) { confirm.click(); await sleep(1500 + Math.random() * 1500); }
    withdrawn.push(`https://www.linkedin.com/in/${slug}`);
    await sleep(2000 + Math.random() * 3000);
  }
  return { success: true, withdrawn, not_found: notFound };
}

// ── Orchestration (runs in the service worker) ────────────────────────────

const TIER_CHECK_EVERY_MS = 12 * 60 * 60 * 1000;

/** Detect the LinkedIn plan at most every 12h (or when forced) and store it in extension_status. */
async function lcMaybeDetectTier(force) {
  if (!supabase.userId) return null;
  const last = await getLocalData('tier_checked_at');
  if (!force && last && Date.now() - last < TIER_CHECK_EVERY_MS) return null;
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  const tab = tabs.find((t) => t.status === 'complete') || tabs[0];
  if (!tab) return null; // needs an open LinkedIn tab (logged in)
  let res;
  try { res = await lcExec(tab.id, lcDetectLinkedInTier, [], 30000); } catch (e) {
    console.warn('[LC:Tier] detection failed:', e.message);
    return null;
  }
  if (!res || !res.tier) {
    // Inconclusive (LinkedIn still loading, logged out...): try again in 30 minutes, not 12 hours.
    await setLocalData('tier_checked_at', Date.now() - TIER_CHECK_EVERY_MS + 30 * 60 * 1000);
    console.log('[LC:Tier] inconclusive', res && res.signals);
    return null;
  }
  await setLocalData('tier_checked_at', Date.now());

  try {
    const cur = await fetch(`${supabase.url}/rest/v1/extension_status?user_id=eq.${supabase.userId}&select=linkedin_account_tier`, {
      headers: supabase.getHeaders(),
    }).then((r) => (r.ok ? r.json() : []));
    const current = cur && cur[0] ? cur[0].linkedin_account_tier : null;
    // Never downgrade Sales Navigator on a weak signal: only when the license check really answered.
    if (current === 'sales_navigator' && res.tier !== 'sales_navigator' && !res.signals.licenses_checked) {
      console.log('[LC:Tier] keeping sales_navigator, license check inconclusive');
      return current;
    }
    const body = { linkedin_tier_detected_at: new Date().toISOString() };
    if (current !== res.tier) body.linkedin_account_tier = res.tier;
    await fetch(`${supabase.url}/rest/v1/extension_status?user_id=eq.${supabase.userId}`, {
      method: 'PATCH',
      headers: supabase.getHeaders(),
      body: JSON.stringify(body),
    });
    console.log('[LC:Tier] plan:', res.tier, current !== res.tier ? `(was ${current})` : '', res.signals);
    return res.tier;
  } catch (e) {
    console.warn('[LC:Tier] save failed:', e.message);
    return null;
  }
}
async function lcNavigate(processor, tabId, url) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: () => { window.onbeforeunload = null; } });
  } catch (_) { /* page may not allow scripting yet */ }
  await chrome.tabs.update(tabId, { url });
  await processor.waitForTabLoad(tabId);
  await processor.sleep(4000 + Math.random() * 3000);
}

async function lcExec(tabId, func, args, timeoutMs) {
  const run = chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] });
  const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error(`Network page script timeout (${(timeoutMs || 120000) / 1000}s)`)), timeoutMs || 120000));
  const results = await Promise.race([run, timeout]);
  if (!results || !results[0]) throw new Error('No result from page script');
  return results[0].result;
}

async function runNetworkAction(processor, tab, action) {
  const data = action.action_data || {};
  switch (action.action_type) {
    case 'network_search_people': {
      await lcNavigate(processor, tab.id, data.search_url || action.linkedin_url);
      if (data.reader === 'sales_navigator') {
        // Sales Navigator is a heavier app: give it a few more seconds before reading.
        await processor.sleep(3000 + Math.random() * 2000);
        return await lcExec(tab.id, lcReadSalesNavSearch, [], 180000);
      }
      return await lcExec(tab.id, lcReadPeopleSearch);
    }
    case 'network_search_posts': {
      await lcNavigate(processor, tab.id, data.search_url || action.linkedin_url);
      return await lcExec(tab.id, lcReadPostSearch);
    }
    case 'network_sync_connections': {
      await lcNavigate(processor, tab.id, 'https://www.linkedin.com/mynetwork/invite-connect/connections/');
      const conns = await lcExec(tab.id, lcReadProfileLinks, [3]);
      await processor.sleep(3000 + Math.random() * 3000);
      await lcNavigate(processor, tab.id, 'https://www.linkedin.com/mynetwork/invitation-manager/sent/');
      const sent = await lcExec(tab.id, lcReadProfileLinks, [4]);
      return { success: true, connections: conns.urls || [], pending: sent.urls || [] };
    }
    case 'network_withdraw_invites': {
      await lcNavigate(processor, tab.id, 'https://www.linkedin.com/mynetwork/invitation-manager/sent/');
      return await lcExec(tab.id, lcWithdrawInvites, [data.profile_urls || []], 180000);
    }
    default:
      throw new Error(`Unknown network action: ${action.action_type}`);
  }
}
