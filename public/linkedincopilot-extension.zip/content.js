// Prevent double injection — guard MUST wrap the message listener too,
// otherwise each injection adds another listener causing duplicate execution
if (window.__linkedinCopilotLoaded) {
  console.log('[LinkedIn Copilot] Content script already loaded, skipping');
  // STOP HERE — do not register another message listener
} else {
  window.__linkedinCopilotLoaded = true;
  console.log('[LinkedIn Copilot] Content script loaded');

  // Listen for action requests from background (registered ONCE only)
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'PING') {
      sendResponse({ pong: true });
      return;
    }
    if (message.type === 'EXECUTE_ACTION') {
      handleAction(message.action)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Keep channel open for async response
    }
  });
}

async function handleAction(action) {
  console.log(`[LinkedIn Copilot] Executing: ${action.action_type}`);

  // Wait for page to be ready
  await waitForLinkedInReady();

  switch (action.action_type) {
    case 'visit_profile':
      return await visitProfile();
    case 'follow_profile':
      return await followProfile();
    case 'send_connection_request':
      return await sendConnectionRequest(action.message_text);
    case 'send_dm':
    case 'send_followup':
      return await sendMessage(action.message_text);
    case 'compose_on_messaging_page':
      return await composeOnMessagingPage(action.message_text, action.expected_name);
    case 'check_connection_status':
      return await checkConnectionStatus();
    case 'check_reply_status':
      return await checkReplyStatus(action);
    default:
      throw new Error(`Unknown action: ${action.action_type}`);
  }
}

// ══════════════════════════════════════════════
// VISIT PROFILE
// ══════════════════════════════════════════════
async function visitProfile() {
  // We're already on the profile page (background navigated us here)
  // Just simulate human browsing behavior

  // Wait a moment
  await sleep(1000 + Math.random() * 2000);

  // Scroll down to simulate reading the profile
  await simulateProfileBrowsing();

  return { success: true, action: 'visit_profile' };
}


// ══════════════════════════════════════════════
// FOLLOW PROFILE
// ══════════════════════════════════════════════
async function followProfile() {
  await sleep(1000 + Math.random() * 2000);
  window.scrollBy(0, 200 + Math.random() * 300);
  await sleep(500 + Math.random() * 1000);

  const allButtons = Array.from(document.querySelectorAll('button'));
  const followButton = allButtons.find(btn => {
    const text = (btn.textContent || '').trim().toLowerCase();
    const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
    return (text === 'follow' || ariaLabel.includes('follow')) &&
           !text.includes('following') && !text.includes('unfollow') &&
           !ariaLabel.includes('following') && !ariaLabel.includes('unfollow');
  });

  if (followButton) {
    followButton.click();
    console.log('[LinkedIn Copilot] Clicked Follow button');
    await sleep(1000 + Math.random() * 1000);
    return { success: true, action: 'follow_profile', followed: true };
  }

  console.log('[LinkedIn Copilot] Follow button not found — may already be following');
  return { success: true, action: 'follow_profile', followed: false, note: 'already_following_or_not_found' };
}

// ══════════════════════════════════════════════
// SEND CONNECTION REQUEST
// ══════════════════════════════════════════════
async function sendConnectionRequest(noteText) {
  await sleep(1000 + Math.random() * 1500);

  // Safety: truncate note if too long (max 200 chars)
  if (noteText && noteText.length > 200) {
    noteText = noteText.substring(0, 197) + '...';
  }

  // ── STEP 1: Check if custom-invite dialog is already open (navigated directly) ──
  let dialogAlreadyOpen = !!document.querySelector('dialog, div[role="dialog"]');
  const isCustomInvitePage = window.location.pathname.includes('/preload/custom-invite');

  if (!dialogAlreadyOpen || !isCustomInvitePage) {
    // ── STEP 1b: Find the Connect button/link on the profile page ──
    const connectButton = await findConnectButton();

    if (!connectButton) {
      // Check if we're already connected (LinkedIn 2026: Message can be a button OR a link)
      const messageElement = document.querySelector('button[aria-label*="Message" i]') ||
        document.querySelector('a[aria-label*="Message" i]') ||
        document.querySelector('a[href*="/messaging/compose/"]');
      if (messageElement) {
        return { success: true, action: 'send_connection_request', note: 'already_connected' };
      }

      // Check if connection request is already pending (LinkedIn 2026: Pending can be a button OR a link)
      const pendingElement = document.querySelector('button[aria-label*="Pending" i]') ||
        document.querySelector('a[aria-label*="Pending" i]') ||
        Array.from(document.querySelectorAll('a, button, span')).find(el => {
          const text = (el.textContent || '').trim().toLowerCase();
          return text.includes('pending') && text.includes('withdraw');
        });
      if (pendingElement) {
        return { success: true, action: 'send_connection_request', note: 'already_pending' };
      }

      throw new Error('Connect button not found on profile page');
    }

    // If it's a <a> link (new LinkedIn 2026 layout), signal background.js to navigate
    if (connectButton.tagName === 'A' && connectButton.href && connectButton.href.includes('custom-invite')) {
      return { success: false, action: 'send_connection_request', redirect: connectButton.href, note: 'custom_invite_redirect' };
    }

    connectButton.click();
    await sleep(1500 + Math.random() * 1000);

    // ── STEP 2: Handle "How do you know" modal ──
    const howDoYouKnowModal = document.querySelector('dialog, div[role="dialog"]');
    if (howDoYouKnowModal) {
      const otherButton = howDoYouKnowModal.querySelector('button[aria-label*="Other" i]');
      if (otherButton) {
        otherButton.click();
        await sleep(800 + Math.random() * 500);
      }

      const connectInsideModal = howDoYouKnowModal.querySelector('button[aria-label*="Connect" i]');
      if (connectInsideModal) {
        connectInsideModal.click();
        await sleep(800 + Math.random() * 500);
      }
    }
  }

  // ── STEP 3: Find and click "Add a note" ──
  if (noteText && noteText.trim().length > 0) {
    const addNoteButton = await findAddNoteButton();

    if (addNoteButton) {
      addNoteButton.click();
      await sleep(800 + Math.random() * 500);

      // ── STEP 4: Find the note textarea and type the message ──
      const noteInput = await findNoteInput();

      if (noteInput) {
        noteInput.focus();
        noteInput.value = '';
        noteInput.textContent = '';
        noteInput.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(300);

        // Use robust insertion for the note (LinkedIn React overwrites char-by-char typing)
        const inserted = await typeNoteRobust(noteInput, noteText);
        await sleep(500 + Math.random() * 500);

        if (!inserted) {
          console.warn('[LinkedIn Copilot] Note insertion incomplete. Retrying with fallback.');
          const retried = await retryNoteInsertion(noteInput, noteText);
          if (!retried) {
            throw new Error('Connection note could not be fully inserted');
          }
        }

        const typedValue = (noteInput.value || noteInput.textContent || '').trim();
        const expectedValue = noteText.trim();
        if (typedValue.length < expectedValue.length * 0.95) {
          throw new Error(`Connection note truncated (${typedValue.length}/${expectedValue.length})`);
        }

        // Dispatch extra events to ensure LinkedIn's Ember.js detects the input change
        // and enables the Send button (Ember binds on focusout/blur, not just input)
        noteInput.dispatchEvent(new Event('focusin', { bubbles: true }));
        noteInput.dispatchEvent(new Event('focusout', { bubbles: true }));
        noteInput.dispatchEvent(new Event('blur', { bubbles: true }));
        noteInput.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
        console.log('[LinkedIn Copilot] Note typed and events dispatched ✅');
      } else {
        console.warn('[LinkedIn Copilot] Note input not found, sending without note');
      }
    } else {
      // Diagnostic: log dialog buttons to help debug selector issues
      const diag = document.querySelector('dialog, div[role="dialog"]');
      if (diag) {
        const btns = Array.from(diag.querySelectorAll('button')).map(b => ({
          text: b.textContent.trim().substring(0, 60),
          ariaLabel: b.getAttribute('aria-label'),
          classes: b.className.substring(0, 80),
        }));
        console.warn('[LinkedIn Copilot] Add a note button not found. Dialog buttons:', JSON.stringify(btns));
      } else {
        console.warn('[LinkedIn Copilot] Add a note button not found — no dialog present');
      }
    }
  }

  // ── STEP 5: Click Send ──
  await sleep(500 + Math.random() * 800);

  const sendButton = await findSendButton();
  if (!sendButton) {
    throw new Error('Send/Submit button not found in connection dialog');
  }

  sendButton.click();
  await sleep(2000 + Math.random() * 1000);

  // ── STEP 6: Verify — check if the dialog closed and button changed ──
  const dialogStillOpen = document.querySelector('dialog, div[role="dialog"]');
  if (dialogStillOpen) {
    const errorMsg = dialogStillOpen.querySelector('.artdeco-inline-feedback__message');
    if (errorMsg) {
      const errText = errorMsg.textContent.trim();
      if (isLimitError(errText)) {
        throw new Error(`LINKEDIN_LIMIT: ${errText}`);
      }
      throw new Error(`LinkedIn error: ${errText}`);
    }
    const dialogText = dialogStillOpen.textContent.toLowerCase();
    if (isLimitError(dialogText)) {
      throw new Error('LINKEDIN_LIMIT: Connection request limit reached');
    }
  }

  // Also check for page-level limit banners (LinkedIn sometimes shows them outside dialogs)
  const pageLimitBanner = detectLinkedInLimitBanner();
  if (pageLimitBanner) {
    console.warn('[LinkedIn Copilot] LinkedIn limit banner detected:', pageLimitBanner);
    // Connection was likely sent, but flag the limit for the queue to pause
    return { success: true, action: 'send_connection_request', note: 'sent_with_note', limitWarning: pageLimitBanner };
  }

  return { success: true, action: 'send_connection_request', note: noteText ? 'sent_with_note' : 'sent_without_note' };
}

// ══════════════════════════════════════════════
// SEND MESSAGE (DM / Follow-up)
// ══════════════════════════════════════════════
async function sendMessage(messageText) {
  if (!messageText || messageText.trim().length === 0) {
    throw new Error('No message text provided');
  }

  await sleep(1000 + Math.random() * 1000);

  // ── STEP 0: Close ALL existing message overlays to prevent cross-chat contamination ──
  const existingOverlays = document.querySelectorAll('.msg-overlay-conversation-bubble');
  for (const overlay of existingOverlays) {
    const closeBtn = overlay.querySelector('button[data-control-name="overlay.close_conversation_window"]') ||
                     overlay.querySelector('.msg-overlay-bubble-header button[aria-label*="Close" i]');
    if (closeBtn && closeBtn.offsetParent !== null) {
      closeBtn.click();
      await sleep(400);
    }
  }
  await sleep(500);

  // ── STEP 0.5: Capture the profile name from the page heading ──
  const profileH1 = document.querySelector('main h1') || document.querySelector('main h2');
  const profileName = profileH1 ? profileH1.textContent.trim().toLowerCase() : null;
  console.log('[LinkedIn Copilot] Target profile name from heading:', profileName);

  // ── STEP 1: Find the Message button/link on their profile (with retry) ──
  let messageButton = null;
  for (let attempt = 0; attempt < 10; attempt++) {
    messageButton = findMessageButton();
    if (messageButton) break;
    if (attempt % 3 === 2) {
      console.log(`[LinkedIn Copilot] sendMessage: Message button not found yet (attempt ${attempt + 1}/10), URL: ${window.location.href}`);
    }
    await sleep(1500);
  }

  if (!messageButton) {
    // Include diagnostic info in error message so it reaches Supabase
    const profileNameEl = document.querySelector('main h1') || document.querySelector('main h2');
    const pName = profileNameEl ? profileNameEl.textContent.trim() : 'NO_HEADING';
    const allBtns = document.querySelectorAll('button, a[role="button"], a[href*="messaging"]');
    const btnTexts = Array.from(allBtns).filter(b => b.offsetParent !== null).map(b => b.textContent.trim().substring(0, 25)).slice(0, 8);
    throw new Error(`Message button not found (url=${window.location.pathname}, heading=${pName}, buttons=${JSON.stringify(btnTexts)})`);
  }

  // LinkedIn 2026: Message is an <a> link that navigates to /messaging/ page
  // instead of opening an overlay. Return redirect to background.js which handles
  // navigation and re-injection (clicking directly destroys content script context).
  //
  // CRITICAL: Only follow /messaging/compose/... or /messaging/thread/new/... URLs.
  // A plain /messaging/ href is the global-nav inbox icon — following that opens
  // whichever thread was last active, which caused the 2026-04-10 incident where
  // 16 DMs all landed in the same (wrong) thread because findMessageButton fell
  // through to that selector. See isValidMessageHref().
  if (messageButton.tagName === 'A') {
    if (!isValidMessageHref(messageButton.href)) {
      throw new Error(`Refused to redirect to non-compose messaging href: "${messageButton.href}" (url=${window.location.pathname})`);
    }
    console.log('[LinkedIn Copilot] Message button is <a> link, returning redirect:', messageButton.href);
    return { success: false, action: 'send_dm', redirect: messageButton.href, note: 'messaging_redirect', profileName };
  }

  messageButton.click();
  await sleep(2000 + Math.random() * 1500);

  // ── STEP 2: Find the message input in the correct chat overlay ──
  const messageInputResult = await waitForMessageInput();

  if (!messageInputResult) {
    throw new Error('Message input not found in chat window');
  }

  const { element: messageInput, overlay: messageOverlay } = messageInputResult;

  // ── STEP 2.5: CRITICAL — Verify the conversation is with the correct person ──
  if (profileName && messageOverlay) {
    const headerEl = messageOverlay.querySelector('.msg-overlay-bubble-header h2, .msg-overlay-bubble-header a, .msg-overlay-bubble-header span.msg-overlay-bubble-header__title');
    const conversationName = headerEl ? headerEl.textContent.trim().toLowerCase() : '';
    console.log('[LinkedIn Copilot] Conversation header name:', conversationName);

    // Compare: the conversation header should contain the profile name (or vice versa)
    // Use first name match as minimum since LinkedIn may abbreviate
    const profileFirstName = profileName.split(/\s+/)[0];
    const conversationFirstName = conversationName.split(/\s+/)[0];

    if (profileFirstName && conversationFirstName && profileFirstName.length > 1 && conversationFirstName.length > 1) {
      const nameMatches = conversationName.includes(profileFirstName) || profileName.includes(conversationFirstName);
      if (!nameMatches) {
        console.error(`[LinkedIn Copilot] RECIPIENT MISMATCH! Profile: "${profileName}" vs Conversation: "${conversationName}". Aborting send.`);
        await closeMessageOverlay(messageOverlay);
        throw new Error(`Recipient mismatch: expected "${profileName}" but chat opened for "${conversationName}". Blocked to prevent sending DM to wrong person.`);
      }
      console.log('[LinkedIn Copilot] ✅ Recipient verified:', profileFirstName);
    }
  }

  // ── STEP 3: Type and verify message integrity before sending ──
  await clearComposer(messageInput);
  await typeHumanLike(messageInput, messageText);

  const isComposerValid = await verifyComposerIntegrity(messageInput, messageText);
  if (!isComposerValid) {
    await closeMessageOverlay(messageOverlay);
    throw new Error('Message integrity check failed — send blocked to prevent garbled DM');
  }

  // Extra safety: re-check for late LinkedIn/React mutations before click
  const isComposerStable = await verifyComposerIntegrity(messageInput, messageText, {
    checks: 5,
    baseDelayMs: 260,
    incrementalDelayMs: 190,
  });

  if (!isComposerStable) {
    await closeMessageOverlay(messageOverlay);
    throw new Error('Late composer mutation detected — send blocked to prevent garbled DM');
  }

  await sleep(500 + Math.random() * 600);

  // ── STEP 4: Click Send in the SAME overlay as the validated composer ──
  const sendButton = findMessageSendButton(messageOverlay);

  if (!sendButton) {
    await closeMessageOverlay(messageOverlay);
    throw new Error('Send button not found in validated message overlay');
  }

  sendButton.click();
  await sleep(2000 + Math.random() * 1000);

  // ── STEP 5: Verify the message was actually sent ──
  // After clicking Send, LinkedIn removes the text from the composer if successful.
  // If the text is still there, the send failed silently.
  // 2026-04-13 fix: increased attempts from 3→4, added thread-match fallback.
  let sendVerified = false;
  for (let attempt = 0; attempt < 4; attempt++) {
    await sleep(attempt === 0 ? 2000 : 1500 + attempt * 500);
    const remainingText = normalizeMessageText(readComposerText(messageInput));
    const expectedText = normalizeMessageText(messageText);

    if (remainingText.length === 0 || remainingText !== expectedText) {
      // Composer cleared or changed = send succeeded
      sendVerified = true;
      break;
    }

    // Text still in composer — try clicking send again (first 2 attempts only)
    if (attempt < 2) {
      console.warn(`[LinkedIn Copilot] Send verification attempt ${attempt + 1}: text still in composer, retrying send`);
      const retryBtn = findMessageSendButton(messageOverlay);
      if (retryBtn && !retryBtn.disabled) {
        retryBtn.click();
        await sleep(1500);
      }
    }
  }

  // Thread-match fallback for overlay: check if message appeared in the bubble list
  if (!sendVerified) {
    try {
      const snippet = (messageText || '').substring(0, 50).toLowerCase();
      const bubbles = messageOverlay?.querySelectorAll?.('.msg-s-event-listitem__body, [class*="msg-s-event"] p') || [];
      const recent = Array.from(bubbles).slice(-5);
      for (const b of recent) {
        if ((b.textContent || '').trim().toLowerCase().includes(snippet)) {
          sendVerified = true;
          console.warn('[LinkedIn Copilot] ⚠️ Overlay composer not cleared but message found in thread — treating as success');
          break;
        }
      }
    } catch (e) {
      console.warn('[LinkedIn Copilot] Overlay thread-match check failed:', e.message);
    }
  }

  // ── STEP 6: Always close the message overlay ──
  await closeMessageOverlay(messageOverlay);

  if (!sendVerified) {
    throw new Error('Send verification failed — message text remained in composer after clicking Send');
  }

  // Forensic telemetry — see composeOnMessagingPage for rationale.
  let overlayHeader = '';
  try {
    const hEl = messageOverlay?.querySelector?.(
      '.msg-overlay-bubble-header h2, .msg-overlay-bubble-header a, .msg-overlay-bubble-header span.msg-overlay-bubble-header__title'
    );
    overlayHeader = hEl ? (hEl.textContent || '').trim().substring(0, 80) : '';
  } catch (_) {}

  return {
    success: true,
    action: 'send_dm',
    note: 'sent_via_overlay',
    telemetry: {
      url_path: window.location.pathname,
      thread_header: overlayHeader || null,
      expected_name: profileName || null,
      text_preview: (messageText || '').substring(0, 40),
      sent_at_client: new Date().toISOString(),
    },
  };
}

async function clearComposer(element) {
  element.focus();
  await sleep(180);

  if (element.tagName === 'DIV') {
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('delete', false);
    element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
  } else {
    element.value = '';
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  await sleep(120);
}

function readComposerText(element) {
  if (!element) return '';
  if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
    return element.value || '';
  }
  return element.innerText || element.textContent || '';
}

function normalizeMessageText(text) {
  return String(text || '')
    .replace(/\u00A0/g, ' ')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

async function verifyComposerIntegrity(element, expectedText, options = {}) {
  const expected = normalizeMessageText(expectedText);
  const checks = Math.max(1, options.checks || 3);
  const baseDelayMs = options.baseDelayMs || 220;
  const incrementalDelayMs = options.incrementalDelayMs || 160;

  // Check multiple times to catch LinkedIn async mutations after typing
  for (let i = 0; i < checks; i++) {
    await sleep(baseDelayMs + i * incrementalDelayMs);
    const current = normalizeMessageText(readComposerText(element));
    if (current !== expected) {
      console.error('[LinkedIn Copilot] Composer mismatch detected, blocking send', {
        expectedLength: expected.length,
        currentLength: current.length,
      });
      return false;
    }
  }

  return true;
}

function getMessageOverlayFromInput(element) {
  if (!element) return null;

  const directOverlay = element.closest('.msg-overlay-conversation-bubble, .msg-overlay-list-bubble');
  if (directOverlay) return directOverlay;

  return document.querySelector('.msg-overlay-conversation-bubble.msg-overlay-conversation-bubble--is-active') ||
         document.querySelector('.msg-overlay-conversation-bubble') ||
         null;
}

async function closeMessageOverlay(overlayRoot = null) {
  const scopes = [];

  if (overlayRoot && overlayRoot.isConnected) {
    scopes.push(overlayRoot);
  }

  const activeOverlay = document.querySelector('.msg-overlay-conversation-bubble.msg-overlay-conversation-bubble--is-active');
  if (activeOverlay && activeOverlay !== overlayRoot) {
    scopes.push(activeOverlay);
  }

  if (scopes.length === 0) {
    scopes.push(document);
  }

  for (const scope of scopes) {
    const closeButton = scope.querySelector('button[data-control-name="overlay.close_conversation_window"]') ||
                        scope.querySelector('.msg-overlay-bubble-header button[aria-label*="Close" i]');
    if (closeButton) {
      closeButton.click();
      await sleep(500);
      return;
    }
  }
}

async function waitForMessageInput(maxWaitMs = 8000) {
  const start = Date.now();

  while (Date.now() - start < maxWaitMs) {
    const selectors = [
      '.msg-overlay-conversation-bubble.msg-overlay-conversation-bubble--is-active div.msg-form__contenteditable[contenteditable="true"]',
      '.msg-overlay-conversation-bubble.msg-overlay-conversation-bubble--is-active div[role="textbox"][contenteditable="true"]',
      'div.msg-form__contenteditable[contenteditable="true"]',
      'div[role="textbox"][aria-label*="message" i]',
      'div.msg-form__msg-content-container div[contenteditable="true"]',
      '.msg-overlay-conversation-bubble div[contenteditable="true"]',
    ];

    for (const selector of selectors) {
      const elements = Array.from(document.querySelectorAll(selector));
      for (const el of elements) {
        if (!el || el.offsetParent === null) continue;
        const overlay = getMessageOverlayFromInput(el);
        if (overlay && overlay.offsetParent === null) continue;
        return { element: el, overlay };
      }
    }

    await sleep(500);
  }

  return null;
}

function findMessageSendButton(overlayRoot = null) {
  const selectors = [
    'button.msg-form__send-button',
    'button[type="submit"][aria-label*="Send" i]',
    '.msg-form__send-btn',
    '.msg-overlay-conversation-bubble button[aria-label*="Send" i]',
  ];

  const scopes = [];

  if (overlayRoot && overlayRoot.isConnected) {
    scopes.push(overlayRoot);
  }

  const activeOverlay = document.querySelector('.msg-overlay-conversation-bubble.msg-overlay-conversation-bubble--is-active');
  if (activeOverlay && activeOverlay !== overlayRoot) {
    scopes.push(activeOverlay);
  }

  if (scopes.length === 0) {
    scopes.push(document);
  }

  for (const scope of scopes) {
    for (const selector of selectors) {
      const btn = scope.querySelector(selector);
      if (btn && btn.offsetParent !== null && !btn.disabled) return btn;
    }
  }

  return null;
}

// ══════════════════════════════════════════════
// COMPOSE MESSAGE ON FULL MESSAGING PAGE (LinkedIn 2026)
// ══════════════════════════════════════════════

// Find the active thread container on /messaging/... pages. Everything we
// query (compose input, send button, header, banners) MUST be scoped to this
// container — doing document.querySelector(...) page-wide is what caused the
// 2026-04-10 "all DMs in one thread" incident, because the sidebar and any
// lingering thread panels contain duplicate compose inputs, send buttons and
// name spans that cause false positives.
function findActiveThreadContainer() {
  const selectors = [
    '.msg-thread',
    '.msg-convo-wrapper',
    '[data-test-conversation-container]',
    '.scaffold-layout__detail .msg-form__msg-content-container',
    '.msg-form', // fallback: the compose form itself acts as a scope
  ];
  for (const sel of selectors) {
    const els = document.querySelectorAll(sel);
    for (const el of els) {
      if (el.offsetParent !== null) {
        // Prefer a container that is also the closest ancestor of a visible compose input
        const compose = el.querySelector('div.msg-form__contenteditable[contenteditable="true"]');
        if (compose && compose.offsetParent !== null) {
          // Walk up from compose to the outer thread/convo scope if possible
          const outer = compose.closest('.msg-thread, .msg-convo-wrapper, [data-test-conversation-container]') || el;
          return outer;
        }
      }
    }
  }
  // Last resort: return the closest ancestor of the most-visible compose input
  const visibleCompose = Array.from(
    document.querySelectorAll('div.msg-form__contenteditable[contenteditable="true"]')
  ).find((el) => el.offsetParent !== null);
  if (visibleCompose) {
    return (
      visibleCompose.closest('.msg-thread, .msg-convo-wrapper, [data-test-conversation-container]') ||
      visibleCompose.closest('.msg-form') ||
      visibleCompose.parentElement
    );
  }
  return null;
}

// Returns a short description of any blocking banner shown inside the active
// thread (e.g. "This member has disabled messaging" / "unable to receive").
// If any such banner is present, we must abort instead of typing into a
// phantom compose that will never deliver.
function detectUnableToReceiveBanner(scope) {
  if (!scope) return null;
  const bannerSelectors = [
    '.msg-s-message-list__event--unable-to-send',
    '.msg-connections-typeahead__member-note',
    '[class*="unable-to-send"]',
    '[class*="unable-to-receive"]',
    '[class*="cannot-send"]',
    '.msg-overlay-messaging-container--unavailable',
  ];
  for (const sel of bannerSelectors) {
    const el = scope.querySelector(sel);
    if (el && el.offsetParent !== null) {
      return (el.textContent || '').trim().substring(0, 100) || 'unable_to_receive_banner_detected';
    }
  }
  // Text-based fallback: look for unmistakable phrases in the thread
  const text = (scope.textContent || '').toLowerCase();
  const phrases = [
    'unable to receive messages',
    'no pueden recibir mensajes',
    'não pode receber mensagens',
    'nao pode receber mensagens',
    'this member only accepts messages',
    'messaging is restricted',
  ];
  for (const p of phrases) {
    if (text.includes(p)) return p;
  }
  return null;
}

async function composeOnMessagingPage(messageText, expectedName) {
  console.log('[LinkedIn Copilot] Composing on messaging page. URL:', window.location.href);

  // Wait for the active thread to render AND contain a VISIBLE compose input.
  // No more "use a hidden compose element" fallback — that was the fast path
  // to sending DMs into phantom composes belonging to other threads.
  const composeSelectors = [
    'div.msg-form__contenteditable[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]',
    'div[aria-label*="Write a message" i][contenteditable="true"]',
    'div[aria-label*="Escriba un mensaje" i][contenteditable="true"]',
    'div[aria-label*="Escreva uma mensagem" i][contenteditable="true"]',
    '[contenteditable="true"][class*="msg"]',
    '.msg-form__msg-content-container [contenteditable="true"]',
  ];

  let threadScope = null;
  let messageInput = null;
  for (let attempt = 0; attempt < 30; attempt++) {
    threadScope = findActiveThreadContainer();
    if (threadScope) {
      // Bail out immediately if the active thread is restricted — no point
      // typing into a compose that LinkedIn will refuse to deliver.
      const banner = detectUnableToReceiveBanner(threadScope);
      if (banner) {
        throw new Error(`RECIPIENT_UNABLE_TO_RECEIVE: ${banner} (url=${window.location.pathname})`);
      }
      for (const sel of composeSelectors) {
        const el = threadScope.querySelector(sel);
        if (el && el.offsetParent !== null) { messageInput = el; break; }
      }
      if (messageInput) break;
    }

    if (attempt % 5 === 4) {
      console.log(`[LinkedIn Copilot] Visible compose input not found yet (attempt ${attempt + 1}/30). URL: ${window.location.pathname}`);
    }
    await sleep(1000);
  }

  if (!messageInput) {
    const editables = document.querySelectorAll('[contenteditable="true"]');
    const editableInfo = Array.from(editables).map(e => ({
      tag: e.tagName, cls: (e.className || '').substring(0, 60),
      label: e.getAttribute('aria-label'), role: e.getAttribute('role'),
      visible: !!e.offsetParent
    }));
    throw new Error(`Visible message compose input not found on messaging page (editables=${JSON.stringify(editableInfo)}, url=${window.location.pathname})`);
  }

  // STRICT recipient verification: read the header of the active thread ONLY
  // (not every <a, span, h2> on the page, which matches dozens of sidebar
  // conversation previews and "verifies" any name). If it doesn't match, abort.
  if (expectedName && threadScope) {
    const expectedFirst = expectedName.split(/\s+/)[0].toLowerCase();
    // Look for the conversation header within the same scaffold panel as the thread
    const headerScope =
      threadScope.closest('.scaffold-layout__detail') ||
      threadScope.closest('.msg-convo-wrapper') ||
      threadScope.parentElement ||
      threadScope;
    const headerSelectors = [
      '.msg-entity-lockup__entity-title',
      '[class*="conversation-header"] a',
      '[class*="conversation-header"] h2',
      '[class*="msg-thread"] h2',
      '.msg-thread__link-to-profile',
      '.msg-compose-form__member-name',
      '.msg-connections-typeahead__selected-pill',
      'h2.msg-entity-lockup__entity-title',
      'h2',
    ];
    let headerText = '';
    for (const sel of headerSelectors) {
      const el = headerScope.querySelector(sel);
      if (el && el.offsetParent !== null) {
        headerText = (el.textContent || '').trim().toLowerCase();
        if (headerText) break;
      }
    }
    console.log('[LinkedIn Copilot] Active thread header:', headerText || '(empty)', 'expected:', expectedName);
    const expectedLower = expectedName.toLowerCase();
    const matches =
      headerText && (
        headerText.includes(expectedFirst) ||
        headerText.includes(expectedLower) ||
        expectedLower.includes(headerText)
      );
    if (!matches) {
      throw new Error(`RECIPIENT_MISMATCH: expected "${expectedName}" but active thread header was "${headerText || '(empty)'}" (url=${window.location.pathname})`);
    }
    // Also re-check for "unable to receive" on the now-active compose — LinkedIn
    // sometimes shows the banner after the thread header loads.
    const lateBanner = detectUnableToReceiveBanner(threadScope);
    if (lateBanner) {
      throw new Error(`RECIPIENT_UNABLE_TO_RECEIVE: ${lateBanner}`);
    }
    console.log('[LinkedIn Copilot] ✅ Recipient verified strictly:', headerText);
  }

  // Capture forensic telemetry that will be returned in the success result so
  // action-completed can persist it into action_queue.result. This lets us
  // detect future variants of the 2026-04-10 "all DMs in one thread" bug
  // IMMEDIATELY (server-side) instead of waiting hours for the user to notice.
  let thread_header_final = '';
  const headerProbeSelectors = [
    '.msg-entity-lockup__entity-title',
    '[class*="conversation-header"] a',
    '[class*="conversation-header"] h2',
    '[class*="msg-thread"] h2',
    '.msg-thread__link-to-profile',
    'h2.msg-entity-lockup__entity-title',
  ];
  const headerProbeScope =
    (threadScope && threadScope.closest('.scaffold-layout__detail')) ||
    (threadScope && threadScope.parentElement) ||
    threadScope ||
    document;
  for (const sel of headerProbeSelectors) {
    const el = headerProbeScope.querySelector(sel);
    if (el && el.offsetParent !== null) {
      thread_header_final = (el.textContent || '').trim().substring(0, 80);
      if (thread_header_final) break;
    }
  }

  // ── Insert text using direct DOM manipulation (fast, works even if element is hidden) ──
  messageInput.focus();
  await sleep(500);

  // Clear existing content
  messageInput.innerHTML = '';
  messageInput.textContent = '';
  messageInput.dispatchEvent(new Event('input', { bubbles: true }));
  await sleep(300);

  // Strategy 1: Set innerHTML with <p> tag (how LinkedIn stores messages)
  messageInput.innerHTML = `<p>${messageText}</p>`;
  messageInput.dispatchEvent(new Event('input', { bubbles: true }));
  messageInput.dispatchEvent(new Event('change', { bubbles: true }));
  await sleep(500);

  // Verify text was set
  let composerText = (messageInput.textContent || '').trim();
  console.log(`[LinkedIn Copilot] After innerHTML set, composer has ${composerText.length} chars (expected ${messageText.length})`);

  // Strategy 2: If innerHTML didn't work, try insertText
  if (composerText.length < messageText.length * 0.5) {
    console.log('[LinkedIn Copilot] innerHTML failed, trying execCommand insertText');
    messageInput.innerHTML = '';
    messageInput.focus();
    await sleep(200);
    document.execCommand('insertText', false, messageText);
    messageInput.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(500);
    composerText = (messageInput.textContent || '').trim();
  }

  // Strategy 3: Try setting textContent directly
  if (composerText.length < messageText.length * 0.5) {
    console.log('[LinkedIn Copilot] insertText failed, trying textContent');
    messageInput.textContent = messageText;
    messageInput.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(500);
    composerText = (messageInput.textContent || '').trim();
  }

  if (composerText.length < messageText.length * 0.5) {
    throw new Error(`Failed to set message text in composer (got ${composerText.length} chars, expected ${messageText.length})`);
  }

  console.log('[LinkedIn Copilot] Message text set successfully');
  await sleep(1000);

  // ── Find Send button SCOPED to the same thread as the compose input ──
  // Critical: use the closest msg-form container to the validated compose,
  // never document.querySelector — otherwise we'd click a send button from a
  // different, unrelated thread (the original 2026-04-10 bug).
  const sendScope =
    messageInput.closest('.msg-form') ||
    messageInput.closest('.msg-form__msg-content-container') ||
    threadScope ||
    messageInput.parentElement;
  if (!sendScope) {
    throw new Error('Could not determine send button scope (no msg-form ancestor of compose)');
  }

  let sendButton = null;
  const sendSelectors = [
    'button.msg-form__send-button',
    'button[type="submit"][class*="msg-form"]',
    'button[aria-label*="Send" i]',
    'button[aria-label*="Enviar" i]',
    'button[aria-label*="Envoyer" i]',
  ];

  for (let attempt = 0; attempt < 10; attempt++) {
    for (const selector of sendSelectors) {
      const btn = sendScope.querySelector(selector);
      if (btn && !btn.disabled && btn.offsetParent !== null) { sendButton = btn; break; }
    }
    if (sendButton) break;
    // Fallback: find by text — ALSO scoped to sendScope
    const scopeButtons = sendScope.querySelectorAll('button');
    for (const btn of scopeButtons) {
      const text = (btn.textContent || '').trim().toLowerCase();
      if ((text === 'send' || text === 'enviar' || text === 'envoyer') && !btn.disabled && btn.offsetParent !== null) {
        sendButton = btn;
        break;
      }
    }
    if (sendButton) break;
    await sleep(1000);
  }

  if (!sendButton) {
    const scopeBtns = sendScope.querySelectorAll('button');
    const btnTexts = Array.from(scopeBtns).map(b => `${b.textContent.trim().substring(0,20)}[disabled=${b.disabled}]`).slice(0, 10);
    throw new Error(`Send button not found in active thread scope (buttons=${JSON.stringify(btnTexts)})`);
  }

  console.log('[LinkedIn Copilot] Clicking Send button:', sendButton.textContent.trim(), sendButton.className);
  sendButton.click();

  // ── Robust send verification ──
  // LinkedIn's compose field can take 3-8s to clear after a successful send.
  // Previous logic waited 3s and threw if text remained → caused 9/14 false
  // positive failures on 2026-04-13.  Now we:
  //   1. Poll the composer for up to 8s (composer-cleared = definitive success)
  //   2. If composer still has text, check thread for the message (thread-match)
  //   3. Only throw if BOTH checks fail

  let composerCleared = false;
  for (let attempt = 0; attempt < 4; attempt++) {
    await sleep(attempt === 0 ? 3000 : 2000);          // 3s, then 2s, 2s, 2s = 9s max
    const remaining = (messageInput.textContent || '').trim();
    if (remaining.length === 0 || remaining.length < messageText.length * 0.3) {
      composerCleared = true;
      break;
    }
    // On first retry, try clicking send again (scoped)
    if (attempt === 0) {
      console.warn('[LinkedIn Copilot] Text still in composer after 3s, retrying send');
      const retryBtn = sendScope.querySelector('button.msg-form__send-button') || sendButton;
      if (retryBtn && !retryBtn.disabled) {
        retryBtn.click();
      }
    }
  }

  // Thread-match fallback: even if composer didn't clear, check whether the
  // message actually landed in the conversation thread.  We look for our
  // text snippet inside the last few message bubbles.
  let threadMatch = false;
  if (!composerCleared) {
    try {
      const snippet = (messageText || '').substring(0, 50).toLowerCase();
      const msgBubbles = document.querySelectorAll(
        '.msg-s-event-listitem__body, .msg-s-message-group__msg, [class*="msg-s-event"] .msg-s-event-listitem__message-bubble'
      );
      // Check last 5 bubbles
      const recentBubbles = Array.from(msgBubbles).slice(-5);
      for (const bubble of recentBubbles) {
        const bubbleText = (bubble.textContent || '').trim().toLowerCase();
        if (bubbleText.includes(snippet)) {
          threadMatch = true;
          break;
        }
      }
    } catch (e) {
      console.warn('[LinkedIn Copilot] Thread-match check failed:', e.message);
    }
  }

  const sendVerified = composerCleared || threadMatch;
  if (!sendVerified) {
    throw new Error('Message may not have been sent — compose input still has content and message not found in thread');
  }
  if (!composerCleared && threadMatch) {
    console.warn('[LinkedIn Copilot] ⚠️ Composer not cleared but message found in thread — treating as success');
  }

  console.log('[LinkedIn Copilot] ✅ Message sent successfully on messaging page');
  return {
    success: true,
    action: 'send_dm',
    note: 'sent_via_messaging_page',
    // Forensic telemetry — persisted to action_queue.result by the backend.
    // Use these to cross-check that each DM actually went to the intended
    // recipient, not whichever thread the script found first on the page.
    telemetry: {
      // The final URL the content script was on when it sent the DM.
      url_path: window.location.pathname,
      // Header of the thread the DM was actually delivered into. This is the
      // single most important field — if it stops matching `expected_name`
      // across multiple leads, the 2026-04-10 bug is back.
      thread_header: thread_header_final || null,
      // The expected recipient name passed in from the profile page heading.
      expected_name: expectedName || null,
      // First 40 chars of the DM text — used to distinguish which lead's
      // generated_message was delivered (each lead has unique personalized text).
      text_preview: (messageText || '').substring(0, 40),
      // Timestamp of delivery (client-side).
      sent_at_client: new Date().toISOString(),
    },
  };
}

// ══════════════════════════════════════════════
// CHECK CONNECTION STATUS
// ══════════════════════════════════════════════
async function checkConnectionStatus() {
  await sleep(1000 + Math.random() * 1000);

  const normalize = (text) => (text || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const profileNameEl = document.querySelector('main h1') || document.querySelector('main h2');
  if (!profileNameEl) {
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'no_heading_found', confidence: 'weak' };
  }
  const profileSection = profileNameEl.closest('section, .artdeco-card, [data-view-name]') || profileNameEl.parentElement?.parentElement;
  if (!profileSection) {
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'no_profile_section', confidence: 'weak' };
  }

  const profileButtons = [...profileSection.querySelectorAll('button, a[role="button"], a[href*="messaging"]')];
  const buttonData = profileButtons.map(btn => ({
    text: normalize(btn.textContent || ''),
    label: normalize(btn.getAttribute('aria-label') || ''),
  }));

  const hasAction = (keywords, exclude = []) => {
    return buttonData.some(({ text, label }) => {
      const combined = `${text} ${label}`;
      if (exclude.some(ex => combined.includes(ex))) return false;
      return keywords.some(k => text === k || label === k || text.includes(k) || label.includes(k));
    });
  };

  const PENDING = ['pending', 'pendente', 'pendiente', 'en attente', 'aguardando', 'em espera', 'in attesa'];
  const CONNECT = ['connect', 'conectar', 'conectar-se', 'se connecter', 'inviter', 'invitar', 'ajouter', 'add'];
  const MESSAGE = ['message', 'mensagem', 'mensaje', 'messaggio'];
  const CONNECTED = ['connected', 'conectado', 'conectada', 'connecté', 'connectée', 'connesso', 'connessa'];
  const REMOVE = ['remove connection', 'remover conexão', 'remover conexao', 'retirer la relation', 'eliminar conexión', 'eliminar conexion'];

  const degreeTexts = [...profileSection.querySelectorAll('span, li, div')]
    .map((el) => normalize(el.textContent || ''))
    .filter((txt) => txt && txt.length <= 48);
  const degreeBlob = degreeTexts.join(' | ');
  const hasFirstDegree = /(\b1st\b|\b1º\b|\b1er\b|\b1\.? grau\b|\b1\.? grado\b|\b1\.? degree\b)/i.test(degreeBlob);

  if (hasAction(PENDING)) {
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'pending', confidence: 'weak' };
  }
  if (hasAction(CONNECT, ['disconnect', 'remover', 'remove'])) {
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'connect_available', confidence: 'weak' };
  }
  if (hasAction(CONNECTED)) {
    return { success: true, action: 'check_connection_status', is_connected: true, note: 'connected_label', confidence: 'strong' };
  }
  if (hasAction(REMOVE)) {
    return { success: true, action: 'check_connection_status', is_connected: true, note: 'remove_connection', confidence: 'strong' };
  }
  if (hasAction(MESSAGE)) {
    if (hasFirstDegree) {
      return { success: true, action: 'check_connection_status', is_connected: true, note: 'message_button_1st', confidence: 'strong' };
    }
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'message_without_1st', confidence: 'weak' };
  }

  const msgLinks = profileSection.querySelectorAll('a[href*="messaging"]');
  if (msgLinks.length > 0) {
    if (hasFirstDegree) {
      return { success: true, action: 'check_connection_status', is_connected: true, note: 'message_link_1st', confidence: 'strong' };
    }
    return { success: true, action: 'check_connection_status', is_connected: false, note: 'message_link_without_1st', confidence: 'weak' };
  }

  if (hasFirstDegree) {
    return { success: true, action: 'check_connection_status', is_connected: true, note: 'first_degree_badge', confidence: 'strong' };
  }

  return { success: true, action: 'check_connection_status', is_connected: false, note: 'no_top_card_buttons', confidence: 'weak' };
}

// ══════════════════════════════════════════════
// CHECK REPLY STATUS
// ──────────────────────────────────────────────
// Author-based detection: we read every message bubble in the thread and
// bucket it into "ours" vs "theirs" based on the sender's profile link or
// an explicit "You" marker. A reply exists iff at least one bubble belongs
// to the lead. Replaces the old `chatMessages.length > 1` heuristic which
// false-positived on any thread with prior history and false-negatived
// when our DM hadn't rendered yet.
// ══════════════════════════════════════════════
async function checkReplyStatus(action) {
  const leadUrl = action?.action_data?.linkedin_url || action?.linkedin_url || "";
  // Extract the lead's LinkedIn slug from the URL — we'll match it against
  // profile links inside the chat thread to classify who sent each message.
  const leadSlug = extractLinkedinSlug(leadUrl);

  const messageButton = findMessageButton();
  if (!messageButton) {
    return { success: true, action: 'check_reply_status', has_reply: false, note: 'not_connected' };
  }

  messageButton.click();
  await sleep(2500 + Math.random() * 1500);

  // Wait up to 4s for bubbles to render (slow networks)
  let events = [];
  for (let i = 0; i < 8; i++) {
    events = Array.from(document.querySelectorAll('.msg-s-event-listitem, .msg-s-message-list__event'));
    if (events.length > 0) break;
    await sleep(500);
  }

  const close = () => {
    const closeBtn = document.querySelector('.msg-overlay-bubble-header button[aria-label*="Close" i]');
    if (closeBtn) closeBtn.click();
  };

  if (events.length === 0) {
    close();
    return { success: true, action: 'check_reply_status', has_reply: false, note: 'no_messages_found' };
  }

  // Classify each event as "ours" or "theirs" or "unknown".
  // Heuristics, in order of reliability:
  //   1. Event has .msg-s-event-listitem__message-bubble--msg-arrived-while-scrolled signals
  //      irrelevant, skip.
  //   2. Author link href contains the lead's slug → theirs.
  //   3. Author link href contains "/in/me/" or the event has
  //      aria-label starting with "You " → ours.
  //   4. Fallback: the first event in the thread is usually ours (our DM),
  //      mark subsequent events with a *different* author as theirs.
  let lastAuthorHref = null;
  let firstAuthorHref = null;
  const classified = [];
  for (const ev of events) {
    // Find the author link for this event (or reuse the previous one,
    // because LinkedIn groups consecutive messages under one author header).
    const authorLink = ev.querySelector('a.msg-s-message-group__profile-link, a.msg-s-event-listitem__link, a[href*="/in/"]');
    const href = authorLink?.getAttribute('href') || lastAuthorHref;
    if (href) {
      lastAuthorHref = href;
      if (!firstAuthorHref) firstAuthorHref = href;
    }

    // Message text
    const bodyEl = ev.querySelector('.msg-s-event-listitem__body, .msg-s-event__content');
    const text = (bodyEl?.textContent || '').trim();
    if (!text) continue;

    // Skip edit-notice / system rows
    if (/^(edited|sent|seen|delivered)$/i.test(text)) continue;

    let who = 'unknown';
    if (leadSlug && href && href.includes(`/in/${leadSlug}`)) {
      who = 'theirs';
    } else if (href && /\/in\/(me|ACoAA)/i.test(href)) {
      // LinkedIn's "You" profile often resolves to /in/me or the session user's own ACoAA-id
      who = 'ours';
    }
    classified.push({ who, text, href });
  }

  // Fallback classification: if nothing was marked "theirs" yet but we saw
  // at least two *distinct* author hrefs, the second distinct author is
  // almost certainly the lead.
  const distinctHrefs = [...new Set(classified.map(c => c.href).filter(Boolean))];
  if (!classified.some(c => c.who === 'theirs') && distinctHrefs.length >= 2) {
    // Assume the first distinct author is "ours" (we sent the DM first).
    const oursHref = distinctHrefs[0];
    for (const c of classified) {
      if (c.href && c.href !== oursHref) c.who = 'theirs';
      else if (c.href === oursHref) c.who = 'ours';
    }
  }

  const theirs = classified.filter(c => c.who === 'theirs');
  const hasReply = theirs.length > 0;
  // Last reply text — truncated to 2KB to keep action_queue payloads small.
  const replyText = hasReply ? theirs[theirs.length - 1].text.slice(0, 2000) : null;

  await sleep(500);
  close();

  return {
    success: true,
    action: 'check_reply_status',
    has_reply: hasReply,
    reply_text: replyText,
    reply_count: theirs.length,
    total_events: classified.length,
    detection_method: distinctHrefs.length >= 2 ? 'distinct_authors' : (leadSlug ? 'slug_match' : 'heuristic_only'),
  };
}

// Extract the LinkedIn slug (the part after /in/) from a full profile URL.
function extractLinkedinSlug(url) {
  if (!url) return null;
  const m = url.match(/\/in\/([^/?#]+)/i);
  return m ? decodeURIComponent(m[1]).toLowerCase() : null;
}

// ══════════════════════════════════════════════
// HELPER FUNCTIONS
// ══════════════════════════════════════════════


// Wait for LinkedIn SPA to finish loading
async function waitForLinkedInReady() {
  const maxWait = 20000; // Increased from 10s to 20s for slow page loads
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    const mainContent = document.querySelector('main') ||
      document.querySelector('.scaffold-layout__main') ||
      document.querySelector('[data-view-name]') ||
      document.querySelector('.scaffold-layout');
    if (mainContent) {
      // Wait for profile actions to load (key indicator page is interactive)
      const actionsReady = document.querySelector('.pvs-profile-actions') ||
        document.querySelector('.pv-top-card-v2-ctas') ||
        document.querySelector('dialog, div[role="dialog"]') ||
        document.querySelector('main button');
      if (actionsReady) {
        await sleep(1500);
        return;
      }
    }
    await sleep(500);
  }

  // Even if timeout, continue — the action handlers will fail gracefully
  console.warn('[LinkedIn Copilot] Page may not be fully loaded after timeout, continuing anyway');
}

// Simulate human-like profile browsing
async function simulateProfileBrowsing() {
  const totalScroll = window.innerHeight * (1.5 + Math.random() * 1.5); // Scroll 1.5-3x viewport
  const steps = 8 + Math.floor(Math.random() * 6); // 8-14 scroll steps
  const stepSize = totalScroll / steps;

  for (let i = 0; i < steps; i++) {
    window.scrollBy({
      top: stepSize + (Math.random() * 30 - 15), // Add jitter
      behavior: 'smooth'
    });
    await sleep(300 + Math.random() * 500); // 300-800ms between scrolls
  }

  // Pause at some point (simulating reading)
  await sleep(2000 + Math.random() * 3000);

  // Scroll back up a bit
  window.scrollBy({ top: -200, behavior: 'smooth' });
  await sleep(500);
}

// ── CONNECTION REQUEST BUTTON FINDERS ──

async function findConnectButton() {
  // New LinkedIn layout (2026): "Connect" is an <a> link already present in the DOM
  // with href containing "custom-invite". Works for both "Follow first" profiles
  // (where Connect is in the More dropdown) and standard profiles.
  const connectMenuItem = document.querySelector('a[href*="custom-invite"]');
  if (connectMenuItem && connectMenuItem.offsetParent !== null) return connectMenuItem;

  const selectors = [
    'main button[aria-label*="connect" i]:not([aria-label*="disconnect" i])',
    'main button[aria-label*="Invite" i]',
    '.pvs-profile-actions button[aria-label*="connect" i]',
    '.pv-top-card-v2-ctas button[aria-label*="connect" i]',
    'div.artdeco-dropdown__content button[aria-label*="connect" i]',
    'button[aria-label*="connect" i][data-control-name*="connect" i]',
  ];

  for (const selector of selectors) {
    const btn = document.querySelector(selector);
    if (btn && btn.offsetParent !== null) return btn;
  }

  // Fallback: look in "More actions" / "More" dropdown
  // Strategy 1: find by aria-label (legacy LinkedIn layout)
  const moreSelectors = [
    'button[aria-label*="More actions" i]',
    'button[aria-label*="More" i].artdeco-dropdown__trigger',
    '.pvs-profile-actions button[aria-label*="More" i]',
    '.pv-top-card-v2-ctas button[aria-label*="More" i]',
  ];

  // Strategy 2: find by text content (new LinkedIn layout — no aria-label)
  let moreButton = null;
  for (const moreSelector of moreSelectors) {
    const btn = document.querySelector(moreSelector);
    if (btn && btn.offsetParent !== null) { moreButton = btn; break; }
  }
  if (!moreButton) {
    const mainButtons = document.querySelectorAll('main button');
    for (const btn of mainButtons) {
      if (btn.textContent.trim() === 'More' && btn.offsetParent !== null) {
        moreButton = btn;
        break;
      }
    }
  }

  if (moreButton) {
      moreButton.click();
      await sleep(800 + Math.random() * 400);

      // Re-check for custom-invite link (may only appear in DOM after More dropdown opens)
      const customInviteAfterMore = document.querySelector('a[href*="custom-invite"]');
      if (customInviteAfterMore) return customInviteAfterMore;

      // Search in all visible dropdown containers (legacy + new layout)
      const dropdowns = document.querySelectorAll('div.artdeco-dropdown__content, div.artdeco-dropdown__content--is-open, ul[role="menu"], div[role="menu"]');
      for (const dropdown of dropdowns) {
        if (!dropdown.offsetParent) continue;
        // Try aria-label match first
        const connectByLabel = dropdown.querySelector('[aria-label*="connect" i]:not([aria-label*="disconnect" i])');
        if (connectByLabel) return connectByLabel;
        // Try text content match — search ALL descendants (div, span, li, etc.)
        const allItems = dropdown.querySelectorAll('li, li span, div[role="button"], div[role="menuitem"], span.display-flex, div.artdeco-dropdown__item, div, span');
        const connectByText = Array.from(allItems).find(
          el => {
            const txt = el.textContent.trim().toLowerCase();
            return (txt === 'connect' || txt === 'conectar') && el.children.length === 0;
          }
        );
        if (connectByText) {
          // Click the closest interactive parent or the element itself
          const clickTarget = connectByText.closest('div[role="menuitem"], li, div[role="button"], div.artdeco-dropdown__item') || connectByText;
          return clickTarget;
        }
      }

      // New LinkedIn layout (2026): dropdown items use <a role="menuitem"> with
      // inner <div aria-label="Invite ... to connect"> and <p>Connect</p>
      // Search broadly after clicking More
      const connectLink = document.querySelector('a[role="menuitem"] div[aria-label*="connect" i]:not([aria-label*="disconnect" i])');
      if (connectLink && connectLink.offsetParent !== null) {
        const clickTarget = connectLink.closest('a[role="menuitem"]') || connectLink;
        return clickTarget;
      }

      // Broader fallback: find any visible element with exact "Connect"/"Conectar" text
      const allLeafElements = document.querySelectorAll('p, span, div, a');
      for (const el of allLeafElements) {
        const txt = el.textContent.trim();
        if ((txt === 'Connect' || txt === 'Conectar') && el.children.length === 0 && el.offsetParent !== null) {
          // Skip main page buttons (Follow/Connect in top card)
          const isMainButton = el.closest('button[aria-label*="Follow" i], button[aria-label*="connect" i]');
          if (!isMainButton) {
            const clickTarget = el.closest('a[role="menuitem"], div[role="menuitem"], li, div[role="button"]') || el;
            return clickTarget;
          }
        }
      }

      // Close the dropdown if Connect not found
      moreButton.click();
      await sleep(300);
  }

  // Last resort: find by text
  const allButtons = document.querySelectorAll('main button, .pvs-profile-actions button, .pv-top-card-v2-ctas button');
  for (const btn of allButtons) {
    if (btn.textContent.trim().toLowerCase() === 'connect' && btn.offsetParent !== null) {
      return btn;
    }
  }

  return null;
}

function findPendingButton() {
  // LinkedIn shows "Pending" button when connection request is awaiting acceptance
  const selectors = [
    'main button[aria-label*="Pending" i]',
    '.pvs-profile-actions button[aria-label*="Pending" i]',
  ];

  for (const selector of selectors) {
    const btn = document.querySelector(selector);
    if (btn && btn.offsetParent !== null) return btn;
  }

  // Fallback: find by text content
  const allButtons = document.querySelectorAll('main button, .pvs-profile-actions button');
  for (const btn of allButtons) {
    const text = btn.textContent.trim().toLowerCase();
    if (text === 'pending' && btn.offsetParent !== null) {
      return btn;
    }
  }

  return null;
}


async function findAddNoteButton() {
  // Wait for dialog to appear with retry
  let dialog = null;
  for (let i = 0; i < 8; i++) {
    dialog = document.querySelector('dialog, div[role="dialog"]') ||
             document.querySelector('.artdeco-modal') ||
             document.querySelector('[data-test-modal]');
    if (dialog) break;
    await sleep(500);
  }

  if (!dialog) {
    console.warn('[LinkedIn Copilot] No dialog found for Add a note');
    return null;
  }

  // Search within the dialog only
  const selectors = [
    'button[aria-label*="Add a note" i]',
    'button[aria-label*="add note" i]',
    'button[aria-label*="Adicionar nota" i]',
    'button[aria-label*="Añadir nota" i]',
    'button[aria-label*="Ajouter une note" i]',
    'button[aria-label*="nota" i]',
    'button[aria-label*="note" i]',
  ];

  for (const selector of selectors) {
    const btn = dialog.querySelector(selector);
    if (btn && btn.offsetParent !== null) return btn;
  }

  // Fallback: find by text content in dialog buttons
  const buttons = dialog.querySelectorAll('button');
  for (const btn of buttons) {
    const text = btn.textContent.trim().toLowerCase();
    if (
      text.includes('add a note') ||
      text.includes('adicionar nota') ||
      text.includes('añadir nota') ||
      text.includes('ajouter') ||
      text === 'add note' ||
      text === 'nota'
    ) return btn;
  }

  // Last resort: look for secondary/ghost button that isn't the primary CTA
  const nonPrimaryButtons = Array.from(buttons).filter(btn => {
    const cls = btn.className || '';
    return (cls.includes('secondary') || cls.includes('ghost') || cls.includes('tertiary')) &&
           btn.offsetParent !== null;
  });
  if (nonPrimaryButtons.length === 1) {
    console.log('[LinkedIn Copilot] Found likely Add a note button via class heuristic');
    return nonPrimaryButtons[0];
  }

  return null;
}

async function findNoteInput() {
  const selectors = [
    'textarea[name="message"]',
    'textarea#custom-message',
    'textarea[placeholder*="message" i]',
    'textarea[placeholder*="nota" i]',
    'textarea[placeholder*="note" i]',
    'div[role="dialog"] textarea',
    'dialog textarea',
    '.artdeco-modal textarea',
    '[data-test-modal] textarea',
  ];

  // Retry up to 6 times (3s total) — textarea appears async after clicking "Add a note"
  for (let attempt = 0; attempt < 6; attempt++) {
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.offsetParent !== null) return el;
    }
    await sleep(500);
  }

  return null;
}

async function findSendButton() {
  // Retry finding the dialog and send button — LinkedIn may render it async
  for (let attempt = 0; attempt < 8; attempt++) {
    const dialog = document.querySelector('dialog, div[role="dialog"]') ||
      document.querySelector('[data-test-modal]') ||
      document.querySelector('.artdeco-modal');
    if (!dialog) {
      await sleep(600);
      continue;
    }

    const selectors = [
      'button[aria-label*="Send" i]',
      'button[aria-label*="invitation" i]',
      'button[aria-label*="Enviar" i]',
      'button[aria-label*="Envoyer" i]',
      'button[data-control-name*="send" i]',
    ];

    for (const selector of selectors) {
      const btn = dialog.querySelector(selector);
      if (btn && btn.offsetParent !== null && !btn.disabled) return btn;
    }

    // Fallback: find primary/cta button in dialog by text
    const buttons = dialog.querySelectorAll('button');
    for (const btn of buttons) {
      const text = btn.textContent.trim().toLowerCase();
      if ((text === 'send' || text === 'send invitation' || text === 'send now' ||
           text === 'enviar' || text === 'enviar convite' || text === 'envoyer') &&
          btn.offsetParent !== null && !btn.disabled) {
        return btn;
      }
    }

    // Also try: primary-styled button in dialog (LinkedIn uses artdeco-button--primary)
    const primaryBtn = dialog.querySelector('button.artdeco-button--primary');
    if (primaryBtn && primaryBtn.offsetParent !== null && !primaryBtn.disabled) {
      return primaryBtn;
    }

    // On custom-invite page: if Send button exists but is disabled, try to force-enable it
    // by re-triggering input events on the textarea (Ember.js may not have detected the input)
    if (attempt >= 3 && window.location.pathname.includes('/preload/custom-invite')) {
      const textarea = dialog.querySelector('textarea');
      if (textarea && textarea.value.trim().length > 0) {
        console.log('[LinkedIn Copilot] Send button disabled — re-triggering textarea events');
        textarea.focus();
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        textarea.dispatchEvent(new Event('focusout', { bubbles: true }));
        textarea.dispatchEvent(new Event('blur', { bubbles: true }));
        // Also try Ember-specific: trigger keyup to simulate real typing
        textarea.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ' ' }));
        textarea.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: ' ' }));
      }

      // Last resort: if the button is still disabled after all retries, force-click it
      if (attempt >= 6) {
        const sendBtn = dialog.querySelector('button[aria-label*="Send" i]') ||
          dialog.querySelector('button.artdeco-button--primary');
        if (sendBtn && sendBtn.offsetParent !== null) {
          console.warn('[LinkedIn Copilot] Force-clicking disabled Send button as last resort');
          sendBtn.disabled = false;
          sendBtn.classList.remove('artdeco-button--disabled');
          return sendBtn;
        }
      }
    }

    await sleep(600);
  }

  return null;
}

// ── MESSAGE BUTTON FINDERS ──

// Reject hrefs that point to the messaging inbox root instead of a specific
// compose/thread. This was the root cause of the "all DMs land in the same
// thread" incident (2026-04-10): findMessageButton used to fall back to
// document.querySelector('a[href*="/messaging/"]') which always matched the
// top-nav Messaging icon (href="/messaging/"), causing the extension to
// redirect every lead to the inbox root — which opens whichever thread the
// user had open last. A valid profile Message link MUST contain /messaging/compose/
// or /messaging/thread/new/ (never plain /messaging/).
function isValidMessageHref(href) {
  if (!href) return false;
  try {
    const u = new URL(href, window.location.origin);
    if (u.hostname && u.hostname !== window.location.hostname) return false;
    const p = u.pathname || '';
    // Plain inbox — reject
    if (p === '/messaging' || p === '/messaging/') return false;
    // Inbox with query but no compose path — reject
    if (p === '/messaging' || p.startsWith('/messaging') && !p.includes('/compose') && !p.includes('/thread/new')) return false;
    return p.includes('/messaging/compose') || p.includes('/messaging/thread/new');
  } catch (_) {
    return false;
  }
}

// Check that an element is inside the profile's top-card / primary-actions
// area, not in the left/right rails, sidebar, footer, global nav, etc.
function isInsideProfileTopCard(el) {
  if (!el) return false;
  // Reject anything inside the global nav bar
  if (el.closest('nav, header, .global-nav, #global-nav, [class*="global-nav"]')) return false;
  // Reject sidebars / rails / footer
  if (el.closest('aside, footer, [class*="right-rail"], [class*="left-rail"], [class*="rail-"]')) return false;
  const profileNameEl = document.querySelector('main h1') || document.querySelector('main h2');
  if (!profileNameEl) return false;
  // The top-card / primary-actions container usually wraps the h1. We accept
  // anything in the same section/card as the h1, OR any descendant of <main>
  // provided it's not in a rail/nav.
  const topCard = profileNameEl.closest('section, [class*="pv-top-card"], [class*="top-card"], .artdeco-card, [data-view-name]');
  if (topCard && topCard.contains(el)) return true;
  const main = document.querySelector('main');
  if (main && main.contains(el)) return true;
  return false;
}

function findMessageButton() {
  // Strategy 1: Prefer scoped search inside the profile top-card / primary-actions.
  const profileNameEl = document.querySelector('main h1') || document.querySelector('main h2');
  if (profileNameEl) {
    // Walk up a few levels looking for the card that contains the action buttons
    const candidates = [
      profileNameEl.closest('[class*="pv-top-card"]'),
      profileNameEl.closest('[class*="top-card"]'),
      profileNameEl.closest('section'),
      profileNameEl.closest('.artdeco-card'),
      profileNameEl.closest('[data-view-name]'),
      profileNameEl.parentElement?.parentElement,
      profileNameEl.parentElement?.parentElement?.parentElement,
    ].filter(Boolean);

    const scopedSelectors = [
      'a[href*="/messaging/compose/"]',
      'a[href*="/messaging/thread/new"]',
      'button[aria-label*="Message" i]',
    ];

    for (const scope of candidates) {
      for (const sel of scopedSelectors) {
        const els = scope.querySelectorAll(sel);
        for (const el of els) {
          if (el.offsetParent === null) continue;
          // For <a> elements, require a compose/thread-new href
          if (el.tagName === 'A' && !isValidMessageHref(el.href)) continue;
          console.log('[LinkedIn Copilot] findMessageButton: found (scoped)', sel, 'href:', el.href || '(button)');
          return el;
        }
      }
      // Text-based match inside the scope (e.g. localized)
      const clickables = scope.querySelectorAll('button, a[role="button"], a');
      for (const el of clickables) {
        if (el.offsetParent === null) continue;
        const text = (el.textContent || '').trim().toLowerCase();
        const label = (el.getAttribute('aria-label') || '').toLowerCase();
        const isMessageText =
          text === 'message' || text === 'mensagem' || text === 'mensaje' ||
          label === 'message' || label.includes('message ') || label.startsWith('message');
        if (!isMessageText) continue;
        // For <a>, must have a valid compose href (reject navbar inbox link)
        if (el.tagName === 'A' && !isValidMessageHref(el.href)) continue;
        console.log('[LinkedIn Copilot] findMessageButton: found (scoped text)', 'href:', el.href || '(button)');
        return el;
      }
    }
  }

  // Strategy 2: Global search but with strict href validation — rejects the
  // global-nav "Messaging" icon which has href="/messaging/" (inbox root).
  const strictSelectors = [
    'a[href*="/messaging/compose/"]',
    'a[href*="/messaging/thread/new"]',
    'button[aria-label*="Message" i]',
  ];
  for (const sel of strictSelectors) {
    const els = document.querySelectorAll(sel);
    for (const el of els) {
      if (el.offsetParent === null) continue;
      if (el.tagName === 'A' && !isValidMessageHref(el.href)) continue;
      if (!isInsideProfileTopCard(el)) continue;
      console.log('[LinkedIn Copilot] findMessageButton: found (strict global)', sel, 'href:', el.href || '(button)');
      return el;
    }
  }

  // Diagnostic: log what buttons are visible for debugging
  const allBtns = document.querySelectorAll('button, a[role="button"], a[href*="messaging"]');
  const btnTexts = Array.from(allBtns).filter(b => b.offsetParent !== null).map(b => `${b.textContent.trim().substring(0, 30)}[${b.href || ''}]`).slice(0, 10);
  console.error('[LinkedIn Copilot] findMessageButton: FAILED. Visible clickables:', JSON.stringify(btnTexts));

  return null;
}

// ── ROBUST NOTE INSERTION (for connection request textarea) ──

async function typeNoteRobust(element, text) {
  element.focus();
  await sleep(200);

  // Strategy 1: Use native input value setter to bypass React's controlled component
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype, 'value'
  )?.set || Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'value'
  )?.set;

  if (nativeInputValueSetter) {
    nativeInputValueSetter.call(element, text);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(300);

    if ((element.value || '').trim() === text.trim()) {
      console.log('[LinkedIn Copilot] Note inserted via native setter ✅');
      return true;
    }
  }

  // Strategy 2: execCommand insertText
  element.focus();
  element.value = '';
  element.dispatchEvent(new Event('input', { bubbles: true }));
  await sleep(100);
  element.select();
  document.execCommand('insertText', false, text);
  element.dispatchEvent(new Event('input', { bubbles: true }));
  await sleep(200);

  if ((element.value || '').trim() === text.trim()) {
    console.log('[LinkedIn Copilot] Note inserted via execCommand ✅');
    return true;
  }

  // Strategy 3: Paste event
  element.focus();
  element.value = '';
  await sleep(100);
  try {
    const clipboardData = new DataTransfer();
    clipboardData.setData('text/plain', text);
    element.dispatchEvent(new ClipboardEvent('paste', {
      bubbles: true, cancelable: true, clipboardData,
    }));
    await sleep(200);

    if ((element.value || '').trim() === text.trim()) {
      console.log('[LinkedIn Copilot] Note inserted via paste ✅');
      return true;
    }
  } catch (e) { /* fallthrough */ }

  // Strategy 4: Character-by-character with periodic React sync (last resort)
  element.value = '';
  element.dispatchEvent(new Event('input', { bubbles: true }));
  await sleep(100);

  // Type in chunks of 20 chars to reduce React overwrite risk
  const chunkSize = 20;
  for (let i = 0; i < text.length; i += chunkSize) {
    const chunk = text.substring(i, Math.min(i + chunkSize, text.length));
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(element, text.substring(0, i + chunk.length));
    } else {
      element.value = text.substring(0, i + chunk.length);
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(80 + Math.random() * 40);
  }
  element.dispatchEvent(new Event('change', { bubbles: true }));
  console.log('[LinkedIn Copilot] Note inserted via chunk typing');
  const finalValue = (element.value || '').trim();
  return finalValue.length >= text.trim().length * 0.95;
}

async function retryNoteInsertion(element, text) {
  // Nuclear retry: use all strategies again with more aggressive approach
  element.focus();
  await sleep(500);

  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype, 'value'
  )?.set;

  if (nativeInputValueSetter) {
    nativeInputValueSetter.call(element, text);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    // Also fire React-specific synthetic events
    element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    await sleep(400);

    const result = (element.value || '').trim();
    if (result.length >= text.trim().length * 0.95) {
      console.log(`[LinkedIn Copilot] Note retry successful: ${result.length}/${text.trim().length} chars ✅`);
      return true;
    }
  }

  console.error(`[LinkedIn Copilot] Note retry failed. Proceeding with whatever was typed.`);
  return false;
}

// ── HUMAN-LIKE TYPING ──

async function typeHumanLike(element, text) {
  element.focus();

  if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
    // Use robust approach for textareas (same as note insertion)
    await typeNoteRobust(element, text);
  } else {
    // For contenteditable divs (LinkedIn messages):
    // Insert in a single operation to minimize React mutation/corruption risk.
    element.focus();

    // Move cursor to end
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);

    const expectedText = normalizeMessageText(text);
    let inserted = false;

    // Try paste event first (closest to normal user behavior in LinkedIn composer)
    try {
      const clipboardData = new DataTransfer();
      clipboardData.setData('text/plain', text);
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData,
      });

      element.dispatchEvent(pasteEvent);
      await sleep(90);

      const pastedText = normalizeMessageText(element.textContent || '');
      inserted = pastedText === expectedText;
    } catch (e) {
      inserted = false;
    }

    // Fallback: execCommand insertText with full payload
    if (!inserted) {
      document.execCommand('insertText', false, text);
      await sleep(100);
      const cmdText = normalizeMessageText(element.textContent || '');
      inserted = cmdText === expectedText;
    }

    // Last-resort deterministic set
    if (!inserted) {
      element.innerHTML = '';
      element.textContent = text;
      await sleep(80);
    }

    element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));

    // Final verification: check if the text matches
    await sleep(120);
    const finalText = normalizeMessageText(element.textContent || '');

    if (finalText !== expectedText) {
      console.warn(`[LinkedIn Copilot] Text mismatch detected. Expected ${expectedText.length} chars, got ${finalText.length}. Attempting full replace.`);
      // Nuclear option: clear and set via single insert with proper events
      element.focus();
      element.innerHTML = '';
      element.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(200);

      // Insert the full text as a single operation
      const sel = window.getSelection();
      const r = document.createRange();
      r.selectNodeContents(element);
      r.collapse(false);
      sel.removeAllRanges();
      sel.addRange(r);
      document.execCommand('insertText', false, text);
      element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      await sleep(250);

      // Final check (strict)
      const recheckText = normalizeMessageText(element.textContent || '');
      if (recheckText !== expectedText) {
        console.error('[LinkedIn Copilot] Message integrity failure after retry. Blocking send.');
        throw new Error('Message integrity failure: typed text does not match expected DM');
      }

      console.log('[LinkedIn Copilot] Text corrected via full replace');
    }
  }
}

async function simulateScroll(pixels) {
  const steps = 3 + Math.floor(Math.random() * 3);
  const stepSize = pixels / steps;

  for (let i = 0; i < steps; i++) {
    window.scrollBy({ top: stepSize, behavior: 'smooth' });
    await sleep(200 + Math.random() * 300);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ══════════════════════════════════════════════
// LINKEDIN LIMIT DETECTION
// ══════════════════════════════════════════════

// Detects if a text string indicates a LinkedIn rate limit
function isLimitError(text) {
  const lower = (text || '').toLowerCase();
  const limitPhrases = [
    'limit', 'restriction', 'too many', 'quota',
    'weekly invitation', 'invitation limit', 'invitations this week',
    'you\'ve reached', 'reached the maximum', 'try again later',
    'slow down', 'temporarily restricted', 'temporarily limited',
    'límite', 'restricción', 'limite', 'restrição',  // ES/PT
  ];
  return limitPhrases.some(phrase => lower.includes(phrase));
}

// Scans the page for LinkedIn limit banners/alerts outside dialogs
function detectLinkedInLimitBanner() {
  const bannerSelectors = [
    '.artdeco-toast-item', '.artdeco-notification',
    '.ip-fuse-limit-alert', '[data-test-artdeco-toast]',
    '.artdeco-inline-feedback', '.global-alert',
  ];
  for (const selector of bannerSelectors) {
    const elements = document.querySelectorAll(selector);
    for (const el of elements) {
      const text = (el.textContent || '').trim();
      if (isLimitError(text)) return text.substring(0, 200);
    }
  }
  // Also check for any visible element with limit-related text near the top of the page
  const alerts = document.querySelectorAll('[role="alert"], [role="status"]');
  for (const el of alerts) {
    const text = (el.textContent || '').trim();
    if (isLimitError(text)) return text.substring(0, 200);
  }
  return null;
}
